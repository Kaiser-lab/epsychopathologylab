function [Data] = VAS_choices(Data)

% VAS MIN MAX VALUES = -300 to 300

%% VARIABLES

Data.VAS_choices = NaN(20,4);
[efforts rewards] = textread('input_VAS_choices.txt','%n%n');

randomisation = randperm(20);
Data.VAS_choices(:,1) = randomisation;


%% INTRO SCREEN

clearkeys;

cgpencol(0,0,0);    % set screen to black background
cgrect;

cgpencol(1,1,1);    % RGB colour setting for FONT (white)
cgfont('Helvetica',25);
cgtext('************************',0,60);
cgtext('V A S  C H O I C E S',0,0);
cgtext('************************',0,-60);

% cgpencol(1,1,1);  % sets color to dark grey
% cgfont('Helvetica',23);
% cgtext('Dr�cken Sie die <Leertaste> um fortzufahren.',0,-280);
cgflip(0,0,0);  % flips offscreen buffer and clears to black

readkeys;
waitkeydown(inf, 71) % wait until Leertaste
clearkeys;


%% VAS FOR 4 EFFORT LEVELS

for i= 1:20
    
    row= randomisation(i);
    effort = efforts(row);
    reward = rewards(row);
    Data.VAS_choices(i,2) = effort;
    Data.VAS_choices(i,3) = reward;


    effort_bar = -100 + (effort/10)* 20;
    effort_string = strcat(num2str(effort),'%');
    position_money = -150;
    
    randNum = randperm(600);
    position_mouse = randNum(1) - 300;
    cgmouse(position_mouse,-250)
    
    bp=0;
    while ~bp
        [x,y,bs,bp]=cgmouse;
        
        switch reward
            case 1
                cgloadbmp(6,'1Fr.bmp')
                cgdrawsprite(6,position_money,0)
            case 1.5
                cgloadbmp(6,'1Fr.bmp')
                cgdrawsprite(6,position_money,Data.coins_offset_y)
                cgloadbmp(7,'50Rp.bmp')
                cgdrawsprite(7,position_money,-Data.coins_offset_y)
            case 2
                cgloadbmp(8,'2Fr.bmp')
                cgdrawsprite(8,position_money,0)
            case 2.5
                cgloadbmp(8,'2Fr.bmp')
                cgdrawsprite(8,position_money,Data.coins_offset_y)
                cgloadbmp(7,'50Rp.bmp')
                cgdrawsprite(7,position_money,-Data.coins_offset_y)
            case 3
                cgloadbmp(8,'2Fr.bmp')
                cgdrawsprite(8,position_money,Data.coins_offset_y)
                cgloadbmp(6,'1Fr.bmp')
                cgdrawsprite(6,position_money,-Data.coins_offset_y)
            case 5
                cgloadbmp(9,'5Fr.bmp')
                cgdrawsprite(9,position_money,0)
        end
        
        % box
        cgpenwid(6)
        cgpencol(1,1,1);          % sets drawing colour to white
        cgdraw(0 - 25,-100, 0 - 25,100)
        cgdraw(0 - 25, 100, 0 + 25, 100)
        cgdraw(0 + 25, 100, 0 + 25, -100)
        cgdraw(0 + 25, -100, 0 - 25,-100)
        
        % effort_level rect
        cgpencol(1,0.25,0) % orange
        cgrect(0, (-100+(0.5*effort*200/100)), 45, effort*200/100)
        
        % effort-level marker
        cgpenwid(6)
        cgpencol(0.25,0.5,1) % sets colour to light blue
        cgdraw(-30, effort_bar, 30, effort_bar) % sets the bar to the according effort level of left choice
        
        % name effort level
        cgfont('Helvetica', Data.size_effort)
        cgtext(effort_string, 0-65, effort_bar);
        
        % name VAS ends
        cgpencol(1,1,1)
        cgfont('Helvetica', 25)
        cgtext('"sehr gut"', 450,-250)
        
        cgtext('"sehr schlecht"',-450,-250)
        
        % Frage
        cgtext('Wie sch�tzen Sie diese Option ein?', 0 , 250)
        
        cgpenwid(4)
        cgpencol(1,1,1)
        cgdraw(-300,-250,300,-250)
        
        cgdraw(-300,-240,-300,-260)
        cgdraw(300,-240,300,-260)
        
        cgdraw(240,-245,240,-255)
        cgdraw(180,-245,180,-255)
        cgdraw(120,-245,120,-255)
        cgdraw(60,-245,60,-255)
        cgdraw(0,-245,0,-255)
        cgdraw(-240,-245,-240,-255)
        cgdraw(-180,-245,-180,-255)
        cgdraw(-120,-245,-120,-255)
        cgdraw(-60,-245,-60,-255)
        
        if x > 300
            x=300;
        end
        
        if x < -300
            x=-300;
        end
        
        if x <= 300 & x >= -300 
            cgpencol(0,1,0)
            cgpenwid(6)
            cgdraw(x,-240,x,-260)
        end
        
        cgflip(0,0,0)
        
    end
    Data.VAS_choices(i,4) = x;
end

cgflip(0,0,0)

end
