%% ITERATIVE EXPANSION
%
%   M. N. Hartmann, Psychiatric University Hospital Zurich, January 2013

%% LOAD SUBJECTS MAX

subject_max = Data.subject_max;

%% READ HAND DYNANOMETER

s = serial('COM3');
s.BaudRate = 38400;
s.Terminator = 'CR';
flag = '!;f ';
fopen(s);

%% VARIABLES

MONEY_LEVELS = [1 1.5 2 2.5 3 5];
EFFORT_LEVELS = [40 60 80 100];

%% PRESPECIFICATIONS

%addpath /Applications/MATLAB_R2012a.app/toolbox/ezyfit/     % path to
%ezyfit toolbox -> not necessary?!

%% DETECT INDIFFERENCE AMOUNTS FOR THE 4 EFFORT LEVELS (40%,60%,80%,100%)

Data.p_effortful_40 = NaN(1,6);            % creates matrix with NaNs for the p_effortful option for the 6 money levels and all subjects
Data.p_effortful_60 = NaN(1,6);            % creates matrix with NaNs for the p_effortful option for the 6 money levels and all subjects
Data.p_effortful_80 = NaN(1,6);            % creates matrix with NaNs for the p_effortful option for the 6 money levels and all subjects
Data.p_effortful_100 = NaN(1,6);           % creates matrix with NaNs for the p_effortful option for the 6 money levels and all subjects

Data.indiff_point = NaN(1,length(EFFORT_LEVELS));

% DATASORTING

datasorted = sortrows(Data.exp_data, [3 5 6 4]);    % sorts rows to make analysis easier


% 40 % EFFORT INDIFFERENCE POINT

for j = 1:5
    p_effortful_40(1,j) = mean(datasorted((j*2-1):(j*2),8));
    p_effortful_40(2,j) = mean(datasorted((j*2-1+40):(j*2+40),7));
end

p_effortful_40 = mean(p_effortful_40);
Data.p_effortful_40 = horzcat(0, p_effortful_40);


ezfit(MONEY_LEVELS, Data.p_effortful_40, 'y(x) = 1 / (1 + b * exp(c * x))'); % fits logistic functions
b = lastfit.m(1);   % coefficient
c = lastfit.m(2);   % coefficient

Data.indiff_point(1) = log(1/b)/c;   % for p = .5 (indifference point)


% 60 % EFFORT INDIFFERENCE POINT

for j = 1:5
    p_effortful_60(1,j) = mean(datasorted((j*2-1+10):(j*2+10),8));
    p_effortful_60(2,j) = mean(datasorted((j*2-1+50):(j*2+50),7));
end

p_effortful_60 = mean(p_effortful_60);
Data.p_effortful_60 = horzcat(0, p_effortful_60);


ezfit(MONEY_LEVELS, Data.p_effortful_60, 'y(x) = 1 / (1 + b * exp(c * x))'); % fits logistic functions
b = lastfit.m(1);   % coefficient
c = lastfit.m(2);   % coefficient

Data.indiff_point(2) = log(1/b)/c;   % for p = .5 (indifference point)


% 80 % EFFORT INDIFFERENCE POINT

for j = 1:5
    p_effortful_80(1,j) = mean(datasorted((j*2-1+20):(j*2+20),8));
    p_effortful_80(2,j) = mean(datasorted((j*2-1+60):(j*2+60),7));
end

p_effortful_80 = mean(p_effortful_80);
Data.p_effortful_80 = horzcat(0, p_effortful_80);


ezfit(MONEY_LEVELS, Data.p_effortful_80, 'y(x) = 1 / (1 + b * exp(c * x))'); % fits logistic functions
b = lastfit.m(1);   % coefficient
c = lastfit.m(2);   % coefficient

Data.indiff_point(3) = log(1/b)/c;   % for p = .5 (indifference point)


% 100 % EFFORT INDIFFERENCE POINT

for j = 1:5
    p_effortful_100(1,j) = mean(datasorted((j*2-1+30):(j*2+30),8));
    p_effortful_100(2,j) = mean(datasorted((j*2-1+70):(j*2+70),7));
end

p_effortful_100 = mean(p_effortful_100);
Data.p_effortful_100 = horzcat(0, p_effortful_100);


ezfit(MONEY_LEVELS, Data.p_effortful_100, 'y(x) = 1 / (1 + b * exp(c * x))'); % fits logistic functions
b = lastfit.m(1);   % coefficient
c = lastfit.m(2);   % coefficient

Data.indiff_point(4) = log(1/b)/c;   % for p = .5 (indifference point)

%% CHECK FOR EFFORT LEVELS WITHOUT CLEAR INDIFFERENCE POINT

needsLess = NaN(1,4);
needsMore = NaN(1,4);

for i = 1:4 % check computed indifference points
    switch i
        case 1
            p_effort = eval('p_effortful_40');
            effortNow = 40;
        case 2
            p_effort = eval('p_effortful_60');
            effortNow = 60;
        case 3
            p_effort = eval('p_effortful_80');
            effortNow = 80;
        case 4
            p_effort = eval('p_effortful_100');
            effortNow = 100;
    end
    
    if p_effort(1) == 1                         % if subject always chose effortful option  -> give less money for effort
        needsLess(i) = effortNow;
    end
    
    if Data.indiff_point(i) < 0 & p_effort(5) < 1 % if subject didnt switch in between 1.5 CHF & 5 CHF -> give more money for effort
        needsMore(i) = effortNow;
    end
end

%% NEEDS LESS MONEY TRIALS

Data.iterativeLess.choiceEffort = NaN(1,12);
Data.iterativeLess.success = NaN(1,12);
Data.iterativeLess.RT = NaN(1,12);
Data.iterativeLess.effort_newton = NaN(12,100);
Data.iterativeLess.effort_newton_mean = NaN(1,12);
Data.iterativeLess.effort_time = NaN(1,12);

for i = 1:4 % go through all effort levels
    
    if isnan(needsLess(i)) == true
       %do nothing
    else
        switch needsLess(i)
            case 40
                effort_right = 40;
            case 60
                effort_right = 60;
            case 80
                effort_right = 80;
            case 100
                effort_right = 100;
        end
        
        for j = 1:3 % three additional money levels
            
            switch j
                case 1
                    reward_right = 1.2;
                case 2
                    reward_right = 1.1;
                case 3
                    reward_right = 1.05;
            end
            
            effort_left = 0;        % default option always left
            reward_left = 1;
            
            reward_left_string = num2str(reward_left);
            reward_right_string = num2str(reward_right);
            effort_bar_left = -100 + (effort_left/10)* 20;
            effort_bar_right = -100 + (effort_right/10)* 20;
            effort_left_string = strcat(num2str(effort_left),'%');  % creates a string e.g. '15%'
            effort_right_string = strcat(num2str(effort_right),'%');
            
            
            % CHOICE SCREEN
            
            %make a sprite for the whole choice screen
            cgpencol(0,0,0);    % set screen to black background
            cgrect;
            cgfreesprite(5) % release prior trial from sprite number 5
            cgmakesprite(5,Data.resolution_width,Data.resolution_heigth)
            cgsetsprite(5)
            
            
            % left choice:
            % box
            cgpenwid(6)
            cgpencol(1,1,1);          % sets drawing colour to white
            cgdraw(Data.position_stimuli_left - 25,-100, Data.position_stimuli_left - 25,100)
            cgdraw(Data.position_stimuli_left - 25, 100, Data.position_stimuli_left + 25, 100)
            cgdraw(Data.position_stimuli_left + 25, 100, Data.position_stimuli_left + 25, -100)
            cgdraw(Data.position_stimuli_left + 25, -100, Data.position_stimuli_left - 25,-100)
            
            % effort_level rect
            cgpencol(1,0.25,0) % orange
            cgrect(Data.position_stimuli_left, (-100+(0.5*effort_left*200/100)), 45, effort_left*200/100)
            
            % effort-level marker
            cgpenwid(6)
            cgpencol(0.25,0.5,1) % sets colour to light blue
            cgdraw(Data.position_stimuli_left-30, effort_bar_left, Data.position_stimuli_left+30, effort_bar_left) % sets the bar to the according effort level of left choice
            
            % name effort level
            cgfont('Helvetica', Data.size_effort)
            cgtext(effort_left_string, Data.position_stimuli_left-65, effort_bar_left);
            
            % display reward (coins)
            switch reward_left
                case 1
                    cgloadbmp(6,'1Fr.bmp')
                    cgdrawsprite(6,Data.position_reward_left,0)
                case 1.05
                    cgloadbmp(6,'1Fr.bmp')
                    cgdrawsprite(6,Data.position_reward_left,Data.coins_offset_y)
                    cgloadbmp(10,'5Rp.bmp')
                    cgdrawsprite(10,Data.position_reward_left,-Data.coins_offset_y)
                case 1.1
                    cgloadbmp(6,'1Fr.bmp')
                    cgdrawsprite(6,Data.position_reward_left,Data.coins_offset_y)
                    cgloadbmp(11,'10Rp.bmp')
                    cgdrawsprite(11,Data.position_reward_left,-Data.coins_offset_y)
                case 1.2
                    cgloadbmp(6,'1Fr.bmp')
                    cgdrawsprite(6,Data.position_reward_left,Data.coins_offset_y)
                    cgloadbmp(12,'20Rp.bmp')
                    cgdrawsprite(12,Data.position_reward_left,-Data.coins_offset_y)
                case 1.5
                    cgloadbmp(6,'1Fr.bmp')
                    cgdrawsprite(6,Data.position_reward_left,Data.coins_offset_y)
                    cgloadbmp(7,'50Rp.bmp')
                    cgdrawsprite(7,Data.position_reward_left,-Data.coins_offset_y)
                case 2
                    cgloadbmp(8,'2Fr.bmp')
                    cgdrawsprite(8,Data.position_reward_left,0)
                case 2.5
                    cgloadbmp(8,'2Fr.bmp')
                    cgdrawsprite(8,Data.position_reward_left,Data.coins_offset_y)
                    cgloadbmp(7,'50Rp.bmp')
                    cgdrawsprite(7,Data.position_reward_left,-Data.coins_offset_y)
                case 3
                    cgloadbmp(8,'2Fr.bmp')
                    cgdrawsprite(8,Data.position_reward_left,Data.coins_offset_y)
                    cgloadbmp(6,'1Fr.bmp')
                    cgdrawsprite(6,Data.position_reward_left,-Data.coins_offset_y)
                case 5
                    cgloadbmp(9,'5Fr.bmp')
                    cgdrawsprite(9,Data.position_reward_left,0)
            end
            
            
            % right choice:
            % box
            cgpenwid(6)
            cgpencol(1,1,1);          % sets drawing colour to white
            cgdraw(Data.position_stimuli_right - 25,-100, Data.position_stimuli_right - 25,100)
            cgdraw(Data.position_stimuli_right - 25, 100, Data.position_stimuli_right + 25, 100)
            cgdraw(Data.position_stimuli_right + 25, 100, Data.position_stimuli_right + 25, -100)
            cgdraw(Data.position_stimuli_right + 25, -100, Data.position_stimuli_right - 25,-100)
            
            % effort_level rect
            cgpencol(1,0.25,0) %
            cgrect(Data.position_stimuli_right, (-100+(0.5*effort_right*200/100)), 45, effort_right*200/100)
            
            % effort-level marker
            cgpenwid(6)
            cgpencol(0.25,0.5,1) % sets colour to light blue
            cgdraw(Data.position_stimuli_right-30, effort_bar_right, Data.position_stimuli_right+30, effort_bar_right) % sets the bar to the according effort level of left choice
            
            % name effort level
            cgfont('Helvetica',Data.size_effort)
            cgtext(effort_right_string, Data.position_stimuli_right-65, effort_bar_right);
            
            % display reward level
            
            % display reward (coins)
            
            switch reward_right
                case 1
                    cgloadbmp(6,'1Fr.bmp')
                    cgdrawsprite(6,Data.position_reward_right,0)
                case 1.05
                    cgloadbmp(6,'1Fr.bmp')
                    cgdrawsprite(6,Data.position_reward_right,Data.coins_offset_y)
                    cgloadbmp(10,'5Rp.bmp')
                    cgdrawsprite(10,Data.position_reward_right,-Data.coins_offset_y)
                case 1.1
                    cgloadbmp(6,'1Fr.bmp')
                    cgdrawsprite(6,Data.position_reward_right,Data.coins_offset_y)
                    cgloadbmp(11,'10Rp.bmp')
                    cgdrawsprite(11,Data.position_reward_right,-Data.coins_offset_y)
                case 1.2
                    cgloadbmp(6,'1Fr.bmp')
                    cgdrawsprite(6,Data.position_reward_right,Data.coins_offset_y)
                    cgloadbmp(12,'20Rp.bmp')
                    cgdrawsprite(12,Data.position_reward_right,-Data.coins_offset_y)
                case 1.5
                    cgloadbmp(6,'1Fr.bmp')
                    cgdrawsprite(6,Data.position_reward_right,Data.coins_offset_y)
                    cgloadbmp(7,'50Rp.bmp')
                    cgdrawsprite(7,Data.position_reward_right,-Data.coins_offset_y)
                case 2
                    cgloadbmp(8,'2Fr.bmp')
                    cgdrawsprite(8,Data.position_reward_right,0)
                case 2.5
                    cgloadbmp(8,'2Fr.bmp')
                    cgdrawsprite(8,Data.position_reward_right,Data.coins_offset_y)
                    cgloadbmp(7,'50Rp.bmp')
                    cgdrawsprite(7,Data.position_reward_right,-Data.coins_offset_y)
                case 3
                    cgloadbmp(8,'2Fr.bmp')
                    cgdrawsprite(8,Data.position_reward_right,Data.coins_offset_y)
                    cgloadbmp(6,'1Fr.bmp')
                    cgdrawsprite(6,Data.position_reward_right,-Data.coins_offset_y)
                case 5
                    cgloadbmp(9,'5Fr.bmp')
                    cgdrawsprite(9,Data.position_reward_right,0)
            end
            
            % draw option boxes (left&right)
            cgpenwid(1)
            cgpencol(1,1,1);          % sets drawing colour to white
            %left
            cgdraw(Data.box_center_left-Data.box_size/2,Data.box_size/2,Data.box_center_left-Data.box_size/2,-Data.box_size/2)
            cgdraw(Data.box_center_left-Data.box_size/2,-Data.box_size/2, Data.box_center_left+Data.box_size/2, -Data.box_size/2)
            cgdraw(Data.box_center_left+Data.box_size/2, -Data.box_size/2, Data.box_center_left+Data.box_size/2, Data.box_size/2)
            cgdraw(Data.box_center_left+Data.box_size/2, Data.box_size/2, Data.box_center_left-Data.box_size/2,Data.box_size/2)
            %right
            cgdraw(Data.box_center_right-Data.box_size/2,Data.box_size/2,Data.box_center_right-Data.box_size/2,-Data.box_size/2)
            cgdraw(Data.box_center_right-Data.box_size/2,-Data.box_size/2, Data.box_center_right+Data.box_size/2, -Data.box_size/2)
            cgdraw(Data.box_center_right+Data.box_size/2, -Data.box_size/2, Data.box_center_right+Data.box_size/2, Data.box_size/2)
            cgdraw(Data.box_center_right+Data.box_size/2, Data.box_size/2, Data.box_center_right-Data.box_size/2,Data.box_size/2)
            
            % draw arrows and question mark
            cgpenwid(3)
            cgpencol(1,1,1);          % sets drawing colour to gray
            cgdraw(-80,-300,-150,-300)  % left arrow
            cgdraw(-150,-300,-130,-280)
            cgdraw(-150,-300,-130,-320)
            cgdraw(80,-300,150,-300)  % right arrow
            cgdraw(150,-300,130,-280)
            cgdraw(150,-300,130,-320)
            
            cgsetsprite(0)
            cgflip(0,0,0)
            
            cgdrawsprite(5,0,0) % draw stimuli presentation screen at 0,0
            
            cgfont('Helvetica', 60) % question mark indicating choice situation
            cgtext('?',0,-300)
            
            cgflip(0,0,0)
            
            t_present = tic;       % start measuring rt
            
            clearkeys;  % clear are stored key presses till now
            readkeys;   % now read all key presses
            
            waitkeydown( inf, [97 98 52] ); % waituntil LEFT or RIGHT is pressed, indexing the choice
            
            Data.iterativeLess.RT(1,(3*i-3+j)) = toc(t_present);  % choice response time measure
            
            [key, ~] = lastkeydown; % last button press
            
            
            if key == 97                    % if LEFT is pressed
                Data.iterativeLess.choiceEffort(1,(3*i-3+j)) = 0;
                cgdrawsprite(5,0,0);
                
                % draw choice confirmation arrow & make choice box blue
                cgpenwid(10)
                cgpencol(1,1,1);          % sets drawing colour to white
                cgdraw(-80,-300,-150,-300)  % left arrow
                cgdraw(-150,-300,-130,-280)
                cgdraw(-150,-300,-130,-320)
                
                cgpenwid(4)
                cgpencol(0,0,1);          % sets drawing colour to blue
                %left
                cgdraw(Data.box_center_left-Data.box_size/2,Data.box_size/2,Data.box_center_left-Data.box_size/2,-Data.box_size/2)
                cgdraw(Data.box_center_left-Data.box_size/2,-Data.box_size/2, Data.box_center_left+Data.box_size/2, -Data.box_size/2)
                cgdraw(Data.box_center_left+Data.box_size/2, -Data.box_size/2, Data.box_center_left+Data.box_size/2, Data.box_size/2)
                cgdraw(Data.box_center_left+Data.box_size/2, Data.box_size/2, Data.box_center_left-Data.box_size/2,Data.box_size/2)
                
                cgflip(0,0,0)
                wait(Data.timing.choice_feedback) % choice confirmation duration
                
                cgpencol(1,1,1);          % sets drawing colour to white
                cgfont('Helvetica', 50);  % font type and font size
                cgtext('+', 0, 0)         % fixation cross x=0, y=0
                if reward_left > 1
                    cgfont('Helvetica', 30);  % font type and font size
                    cgtext('ACHTUNG GLEICH M�SSEN SIE DR�CKEN',0,70 )    % text at x=0, y=70
                end
                cgflip(0,0,0)             % flips stuff from the buffer onto the screen
                
                wait(Data.timing.fixation_afterchoice)
                
                clear g newton
                newton = zeros(1,100);
                g = zeros(1, 100);
                
                effort_time = tic;
                
             for k = 1:100
                    time1 = time;
                    fprintf(s,';f?');
                    out = fscanf(s);
                    y = str2num(strrep(out, flag, ''));
                    newton(k) = y;
                    y = ((y/subject_max)*190);
                    g(k)=y;
                    
                    % draw feedback bar
                    cgpenwid(6)
                    cgpencol(1,1,1)
                    cgdraw(-25,-100,-25,100)
                    cgdraw(-25,100, 25, 100);
                    cgdraw(-25,-100, 25, -100)
                    cgdraw(25,100, 25, -100)
                    cgpencol(1,0.25,0)
                    cgrect(0,-97.5+(y/2),45,y)
                    
                    % draw effort-level
                    cgpenwid(6)
                    cgpencol(0.25,0.5,1) % sets colour to light blue
                    cgdraw(-30, effort_bar_left, 30, effort_bar_left) % sets the bar to the according effort level of left choice
                    
                    % name effort level
                    cgfont('Helvetica', Data.size_effort)
                    cgtext(effort_left_string,-65, effort_bar_left);
                    
                    % draw feedback arc
                    cgpencol(0,1,0)
                    cgpenwid(10)
                    cgarc(0,230,75,75,0,0+((k)*3.6))
                    if reward_left > 1
                        cgpencol(1,1,1)
                        cgfont('Helvetica',30)
                        cgtext('DR�CKEN!',0,300)
                    end
                    cgflip(0,0,0)
                    waituntil(time1+Data.timing.effort)
                end
                
                tElapsed = toc(effort_time);
                Data.iterativeLess.effort_time(1,(3*i-3+j)) = tElapsed;      % saves elapsed time in this trial
                
                Data.iterativeLess.effort_newton((3*i-3+j), 1:100) = newton;               % writes newton values of 100 loops to file
                Data.iterativeLess.effort_newton_mean(1,(3*i-3+j)) = mean(newton);
                
                
                % criterion if expended effort was sufficient to reach effort level
                % and according feedback
                
                if mean(Data.iterativeLess.effort_newton((3*i-3+j), 34:100)) >= Data.subject_max * ((effort_left)/100) * Data.forcemargin   % if the last 2/3 of the effort is >= than subj max
                    
                    Data.iterativeLess.success(1,(3*i-3+j)) = 1;     % writes 1 for success
                    
                    switch reward_left
                        case 1
                            cgpencol(0,1,0)
                            cgfont('Helvetica', Data.size_reward_feedback)
                            cgtext('Gewonnen!',0,160)
                            cgloadbmp(6,'1Fr.bmp')
                            cgdrawsprite(6,0,0)
                        case 1.05
                            cgpencol(0,1,0)
                            cgfont('Helvetica', Data.size_reward_feedback)
                            cgtext('Gewonnen!',0,160)
                            cgloadbmp(6,'1Fr.bmp')
                            cgdrawsprite(6,0,Data.coins_offset_y)
                            cgloadbmp(10,'5Rp.bmp')
                            cgdrawsprite(10,0,-Data.coins_offset_y)
                        case 1.1
                            cgpencol(0,1,0)
                            cgfont('Helvetica', Data.size_reward_feedback)
                            cgtext('Gewonnen!',0,160)
                            cgloadbmp(6,'1Fr.bmp')
                            cgdrawsprite(6,0,Data.coins_offset_y)
                            cgloadbmp(11,'10Rp.bmp')
                            cgdrawsprite(11,0,-Data.coins_offset_y)
                        case 1.2
                            cgpencol(0,1,0)
                            cgfont('Helvetica', Data.size_reward_feedback)
                            cgtext('Gewonnen!',0,160)
                            cgloadbmp(6,'1Fr.bmp')
                            cgdrawsprite(6,0,Data.coins_offset_y)
                            cgloadbmp(12,'20Rp.bmp')
                            cgdrawsprite(12,0,-Data.coins_offset_y)
                        case 1.5
                            cgpencol(0,1,0)
                            cgfont('Helvetica', Data.size_reward_feedback)
                            cgtext('Gewonnen!',0,160)
                            cgloadbmp(6,'1Fr.bmp')
                            cgdrawsprite(6,0,Data.coins_offset_y)
                            cgloadbmp(7,'50Rp.bmp')
                            cgdrawsprite(7,0,-Data.coins_offset_y)
                        case 2
                            cgpencol(0,1,0)
                            cgfont('Helvetica', Data.size_reward_feedback)
                            cgtext('Gewonnen!',0,160)
                            cgloadbmp(8,'2Fr.bmp')
                            cgdrawsprite(8,0,0)
                        case 2.5
                            cgpencol(0,1,0)
                            cgfont('Helvetica', Data.size_reward_feedback)
                            cgtext('Gewonnen!',0,160)
                            cgloadbmp(8,'2Fr.bmp')
                            cgdrawsprite(8,0,Data.coins_offset_y)
                            cgloadbmp(7,'50Rp.bmp')
                            cgdrawsprite(7,0,-Data.coins_offset_y)
                        case 3
                            cgpencol(0,1,0)
                            cgfont('Helvetica', Data.size_reward_feedback)
                            cgtext('Gewonnen!',0,160)
                            cgloadbmp(8,'2Fr.bmp')
                            cgdrawsprite(8,0,Data.coins_offset_y)
                            cgloadbmp(6,'1Fr.bmp')
                            cgdrawsprite(6,0,-Data.coins_offset_y)
                        case 5
                            cgpencol(0,1,0)
                            cgfont('Helvetica', Data.size_reward_feedback)
                            cgtext('Gewonnen!',0,160)
                            cgloadbmp(9,'5Fr.bmp')
                            cgdrawsprite(9,0,0)
                    end
                    
                    cgflip(0,0,0)
                    wait(Data.timing.feedback)
                    
                else
                    
                    Data.iterativeLess.success(1,(3*i-3+j)) = 0;     % writes 0 for failed
                    
                    cgpencol(1,1,1)
                    cgfont('Helvetica', Data.text_size)
                    cgtext('Leider nicht geschafft... Das n�chste mal st�rker dr�cken...',0,80)
                    cgloadbmp(6,'1Fr.bmp')
                    cgdrawsprite(6,0,0)
                    
                    cgflip(0,0,0);
                    wait(Data.timing.feedback)
                end
            end
            
            %%%%%
            if key == 98                    % if RIGHT is pressed
                Data.iterativeLess.choiceEffort(1,(3*i-3+j)) = 1;
                
                cgdrawsprite(5,0,0);
                
                % draw choice confirmation arrow & make choice box blue
                cgpenwid(10)
                cgpencol(1,1,1);          % sets drawing colour to white
                cgdraw(80,-300,150,-300)  % right arrow
                cgdraw(150,-300,130,-280)
                cgdraw(150,-300,130,-320)
                
                cgpenwid(4)
                cgpencol(0,0,1);          % sets drawing colour to blue
                %right
                cgdraw(Data.box_center_right-Data.box_size/2,Data.box_size/2,Data.box_center_right-Data.box_size/2,-Data.box_size/2)
                cgdraw(Data.box_center_right-Data.box_size/2,-Data.box_size/2, Data.box_center_right+Data.box_size/2, -Data.box_size/2)
                cgdraw(Data.box_center_right+Data.box_size/2, -Data.box_size/2, Data.box_center_right+Data.box_size/2, Data.box_size/2)
                cgdraw(Data.box_center_right+Data.box_size/2, Data.box_size/2, Data.box_center_right-Data.box_size/2,Data.box_size/2)
                
                cgflip(0,0,0)
                wait(Data.timing.choice_feedback) % choice confirmation duration
                
                cgpencol(1,1,1);          % sets drawing colour to white
                cgfont('Helvetica', 50);  % font type and font size
                cgtext('+', 0, 0)         % fixation cross x=0, y=0
                if reward_right > 1
                    cgfont('Helvetica', 30);  % font type and font size
                    cgtext('ACHTUNG GLEICH M�SSEN SIE DR�CKEN',0,70 )    % text at x=0, y=70
                end
                cgflip(0,0,0)             % flips stuff from the buffer onto the screen
                
                wait(Data.timing.fixation_afterchoice)
                
                clear g newton
                newton = zeros(1,100);
                g = zeros(1, 100);
                
                effort_time = tic;
                
                for k = 1:100
                    time1 = time;
                    fprintf(s,';f?');
                    out = fscanf(s);
                    y = str2num(strrep(out, flag, ''));
                    newton(k) = y;
                    y = ((y/subject_max)*190);
                    g(k)=y;
                    
                    % draw feedback bar
                    cgpenwid(6)
                    cgpencol(1,1,1)
                    cgdraw(-25,-100,-25,100)
                    cgdraw(-25,100, 25, 100);
                    cgdraw(-25,-100, 25, -100)
                    cgdraw(25,100, 25, -100)
                    cgpencol(1,0.25,0)
                    cgrect(0,-97.5+(y/2),45,y)
                    
                    % draw effort-level
                    cgpenwid(6)
                    cgpencol(0.25,0.5,1) % sets colour to light blue
                    cgdraw(-30, effort_bar_right, 30, effort_bar_right) % sets the bar to the according effort level of left choice
                    
                    % name effort level
                    cgfont('Helvetica', Data.size_effort)
                    cgtext(effort_right_string,-65, effort_bar_right);
                    
                    % draw feedback arc
                    cgpencol(0,1,0)
                    cgpenwid(10)
                    cgarc(0,230,75,75,0,0+((k)*3.6))
                    if reward_right > 1
                        cgpencol(1,1,1)
                        cgfont('Helvetica',30)
                        cgtext('DR�CKEN!',0,300)
                    end
                    
                    cgflip(0,0,0)
                    waituntil(time1+Data.timing.effort)
                end
                
                tElapsed = toc(effort_time);
                Data.iterativeLess.effort_time(1,(3*i-3+j)) = tElapsed;      % saves elapsed time in this trial
                
                Data.iterativeLess.effort_newton((3*i-3+j), 1:100) = newton;               % writes newton values of 100 loops to file
                Data.iterativeLess.effort_newton_mean(1,(3*i-3+j)) = mean(newton);
                
                % criterion if expended effort was sufficient to reach effort level
                % and according feedback
                
                if mean(Data.iterativeLess.effort_newton((3*i-3+j), 34:100)) >= Data.subject_max * ((effort_right)/100) * Data.forcemargin    % if the last 2/3 of the effort is >= than subj max
                    
                    Data.iterativeLess.sucess(1,(3*i-3+j)) = 1;     % writes 1 for success
                    
                    switch reward_right
                        case 1
                            cgpencol(0,1,0)
                            cgfont('Helvetica', Data.size_reward_feedback)
                            cgtext('Gewonnen!',0,160)
                            cgloadbmp(6,'1Fr.bmp')
                            cgdrawsprite(6,0,0)
                        case 1.05
                            cgpencol(0,1,0)
                            cgfont('Helvetica', Data.size_reward_feedback)
                            cgtext('Gewonnen!',0,160)
                            cgloadbmp(6,'1Fr.bmp')
                            cgdrawsprite(6,0,Data.coins_offset_y)
                            cgloadbmp(10,'5Rp.bmp')
                            cgdrawsprite(10,0,-Data.coins_offset_y)
                        case 1.1
                            cgpencol(0,1,0)
                            cgfont('Helvetica', Data.size_reward_feedback)
                            cgtext('Gewonnen!',0,160)
                            cgloadbmp(6,'1Fr.bmp')
                            cgdrawsprite(6,0,Data.coins_offset_y)
                            cgloadbmp(11,'10Rp.bmp')
                            cgdrawsprite(11,0,-Data.coins_offset_y)
                        case 1.2
                            cgpencol(0,1,0)
                            cgfont('Helvetica', Data.size_reward_feedback)
                            cgtext('Gewonnen!',0,160)
                            cgloadbmp(6,'1Fr.bmp')
                            cgdrawsprite(6,0,Data.coins_offset_y)
                            cgloadbmp(12,'20Rp.bmp')
                            cgdrawsprite(12,0,-Data.coins_offset_y)
                        case 1.5
                            cgpencol(0,1,0)
                            cgfont('Helvetica', Data.size_reward_feedback)
                            cgtext('Gewonnen!',0,160)
                            cgloadbmp(6,'1Fr.bmp')
                            cgdrawsprite(6,0,Data.coins_offset_y)
                            cgloadbmp(7,'50Rp.bmp')
                            cgdrawsprite(7,0,-Data.coins_offset_y)
                        case 2
                            cgpencol(0,1,0)
                            cgfont('Helvetica', Data.size_reward_feedback)
                            cgtext('Gewonnen!',0,160)
                            cgloadbmp(8,'2Fr.bmp')
                            cgdrawsprite(8,0,0)
                        case 2.5
                            cgpencol(0,1,0)
                            cgfont('Helvetica', Data.size_reward_feedback)
                            cgtext('Gewonnen!',0,160)
                            cgloadbmp(8,'2Fr.bmp')
                            cgdrawsprite(8,0,Data.coins_offset_y)
                            cgloadbmp(7,'50Rp.bmp')
                            cgdrawsprite(7,0,-Data.coins_offset_y)
                        case 3
                            cgpencol(0,1,0)
                            cgfont('Helvetica', Data.size_reward_feedback)
                            cgtext('Gewonnen!',0,160)
                            cgloadbmp(8,'2Fr.bmp')
                            cgdrawsprite(8,0,Data.coins_offset_y)
                            cgloadbmp(6,'1Fr.bmp')
                            cgdrawsprite(6,0,-Data.coins_offset_y)
                        case 5
                            cgpencol(0,1,0)
                            cgfont('Helvetica', Data.size_reward_feedback)
                            cgtext('Gewonnen!',0,160)
                            cgloadbmp(9,'5Fr.bmp')
                            cgdrawsprite(9,0,0)
                    end
                    
                    cgflip(0,0,0)
                    wait(Data.timing.feedback)
                    
                else
                    
                    Data.iterativeLess.sucess(1,(3*i-3+j)) = 0;     % writes 0 for no success
                    
                    cgpencol(1,1,1)
                    cgfont('Helvetica', Data.text_size)
                    cgtext('Leider nicht geschafft... Das n�chste mal st�rker dr�cken...',0,80)
                    cgloadbmp(6,'1Fr.bmp')
                    cgdrawsprite(6,0,0)
                    
                    cgflip(0,0,0);
                    wait(Data.timing.feedback)
                    
                end
            end
        end
    end
end

%% NEEDS MORE MONEY TRIALS

Data.iterativeMore.choiceEffort = NaN(1,12);
Data.iterativeMore.success = NaN(1,12);
Data.iterativeMore.RT = NaN(1,12);
Data.iterativeMore.effort_newton = NaN(12,100);
Data.iterativeMore.effort_newton_mean = NaN(1,12);
Data.iterativeMore.effort_time = NaN(1,12);

for i = 1:4 % go through all effort levels
    
    if isnan(needsMore(i)) == true
        % do nothing
    else  
        Data.coins_offset_y = 64;   % give some space for the bigger coins
        switch needsMore(i)
            case 40
                effort_right = 40;
            case 60
                effort_right = 60;
            case 80
                effort_right = 80;
            case 100
                effort_right = 100;
        end
        
        for j = 1:3 % three additional money levels
            
            switch j
                case 1
                    reward_right = 6;
                case 2
                    reward_right = 7;
                case 3
                    reward_right = 10;
            end
            
            effort_left = 0;        % default option always left
            reward_left = 1;
            
            reward_left_string = num2str(reward_left);
            reward_right_string = num2str(reward_right);
            effort_bar_left = -100 + (effort_left/10)* 20;
            effort_bar_right = -100 + (effort_right/10)* 20;
            effort_left_string = strcat(num2str(effort_left),'%');  % creates a string e.g. '15%'
            effort_right_string = strcat(num2str(effort_right),'%');
            
            
            % CHOICE SCREEN
            
            %make a sprite for the whole choice screen
            cgpencol(0,0,0);    % set screen to black background
            cgrect;
            cgfreesprite(5) % release prior trial from sprite number 5
            cgmakesprite(5,Data.resolution_width,Data.resolution_heigth)
            cgsetsprite(5)
            
            
            % left choice:
            % box
            cgpenwid(6)
            cgpencol(1,1,1);          % sets drawing colour to white
            cgdraw(Data.position_stimuli_left - 25,-100, Data.position_stimuli_left - 25,100)
            cgdraw(Data.position_stimuli_left - 25, 100, Data.position_stimuli_left + 25, 100)
            cgdraw(Data.position_stimuli_left + 25, 100, Data.position_stimuli_left + 25, -100)
            cgdraw(Data.position_stimuli_left + 25, -100, Data.position_stimuli_left - 25,-100)
            
            % effort_level rect
            cgpencol(1,0.25,0) % orange
            cgrect(Data.position_stimuli_left, (-100+(0.5*effort_left*200/100)), 45, effort_left*200/100)
            
            % effort-level marker
            cgpenwid(6)
            cgpencol(0.25,0.5,1) % sets colour to light blue
            cgdraw(Data.position_stimuli_left-30, effort_bar_left, Data.position_stimuli_left+30, effort_bar_left) % sets the bar to the according effort level of left choice
            
            % name effort level
            cgfont('Helvetica', Data.size_effort)
            cgtext(effort_left_string, Data.position_stimuli_left-65, effort_bar_left);
            
            % display reward (coins)
            switch reward_left
                case 1
                    cgloadbmp(6,'1Fr.bmp')
                    cgdrawsprite(6,Data.position_reward_left,0)
                case 1.05
                    cgloadbmp(6,'1Fr.bmp')
                    cgdrawsprite(6,Data.position_reward_left,Data.coins_offset_y)
                    cgloadbmp(10,'5Rp.bmp')
                    cgdrawsprite(10,Data.position_reward_left,-Data.coins_offset_y)
                case 1.1
                    cgloadbmp(6,'1Fr.bmp')
                    cgdrawsprite(6,Data.position_reward_left,Data.coins_offset_y)
                    cgloadbmp(11,'10Rp.bmp')
                    cgdrawsprite(11,Data.position_reward_left,-Data.coins_offset_y)
                case 1.2
                    cgloadbmp(6,'1Fr.bmp')
                    cgdrawsprite(6,Data.position_reward_left,Data.coins_offset_y)
                    cgloadbmp(12,'20Rp.bmp')
                    cgdrawsprite(12,Data.position_reward_left,-Data.coins_offset_y)
                case 1.5
                    cgloadbmp(6,'1Fr.bmp')
                    cgdrawsprite(6,Data.position_reward_left,Data.coins_offset_y)
                    cgloadbmp(7,'50Rp.bmp')
                    cgdrawsprite(7,Data.position_reward_left,-Data.coins_offset_y)
                case 2
                    cgloadbmp(8,'2Fr.bmp')
                    cgdrawsprite(8,Data.position_reward_left,0)
                case 2.5
                    cgloadbmp(8,'2Fr.bmp')
                    cgdrawsprite(8,Data.position_reward_left,Data.coins_offset_y)
                    cgloadbmp(7,'50Rp.bmp')
                    cgdrawsprite(7,Data.position_reward_left,-Data.coins_offset_y)
                case 3
                    cgloadbmp(8,'2Fr.bmp')
                    cgdrawsprite(8,Data.position_reward_left,Data.coins_offset_y)
                    cgloadbmp(6,'1Fr.bmp')
                    cgdrawsprite(6,Data.position_reward_left,-Data.coins_offset_y)
                case 5
                    cgloadbmp(9,'5Fr.bmp')
                    cgdrawsprite(9,Data.position_reward_left,0)
            end
            
            
            % right choice:
            % box
            cgpenwid(6)
            cgpencol(1,1,1);          % sets drawing colour to white
            cgdraw(Data.position_stimuli_right - 25,-100, Data.position_stimuli_right - 25,100)
            cgdraw(Data.position_stimuli_right - 25, 100, Data.position_stimuli_right + 25, 100)
            cgdraw(Data.position_stimuli_right + 25, 100, Data.position_stimuli_right + 25, -100)
            cgdraw(Data.position_stimuli_right + 25, -100, Data.position_stimuli_right - 25,-100)
            
            % effort_level rect
            cgpencol(1,0.25,0) %
            cgrect(Data.position_stimuli_right, (-100+(0.5*effort_right*200/100)), 45, effort_right*200/100)
            
            % effort-level marker
            cgpenwid(6)
            cgpencol(0.25,0.5,1) % sets colour to light blue
            cgdraw(Data.position_stimuli_right-30, effort_bar_right, Data.position_stimuli_right+30, effort_bar_right) % sets the bar to the according effort level of left choice
            
            % name effort level
            cgfont('Helvetica',Data.size_effort)
            cgtext(effort_right_string, Data.position_stimuli_right-65, effort_bar_right);
            
            % display reward level
            
            % display reward (coins)
            
            switch reward_right
                case 1
                    cgloadbmp(6,'1Fr.bmp')
                    cgdrawsprite(6,Data.position_reward_right,0)
                case 1.05
                    cgloadbmp(6,'1Fr.bmp')
                    cgdrawsprite(6,Data.position_reward_right,Data.coins_offset_y)
                    cgloadbmp(10,'5Rp.bmp')
                    cgdrawsprite(10,Data.position_reward_right,-Data.coins_offset_y)
                case 1.1
                    cgloadbmp(6,'1Fr.bmp')
                    cgdrawsprite(6,Data.position_reward_right,Data.coins_offset_y)
                    cgloadbmp(11,'10Rp.bmp')
                    cgdrawsprite(11,Data.position_reward_right,-Data.coins_offset_y)
                case 1.2
                    cgloadbmp(6,'1Fr.bmp')
                    cgdrawsprite(6,Data.position_reward_right,Data.coins_offset_y)
                    cgloadbmp(12,'20Rp.bmp')
                    cgdrawsprite(12,Data.position_reward_right,-Data.coins_offset_y)
                case 1.5
                    cgloadbmp(6,'1Fr.bmp')
                    cgdrawsprite(6,Data.position_reward_right,Data.coins_offset_y)
                    cgloadbmp(7,'50Rp.bmp')
                    cgdrawsprite(7,Data.position_reward_right,-Data.coins_offset_y)
                case 2
                    cgloadbmp(8,'2Fr.bmp')
                    cgdrawsprite(8,Data.position_reward_right,0)
                case 2.5
                    cgloadbmp(8,'2Fr.bmp')
                    cgdrawsprite(8,Data.position_reward_right,Data.coins_offset_y)
                    cgloadbmp(7,'50Rp.bmp')
                    cgdrawsprite(7,Data.position_reward_right,-Data.coins_offset_y)
                case 3
                    cgloadbmp(8,'2Fr.bmp')
                    cgdrawsprite(8,Data.position_reward_right,Data.coins_offset_y)
                    cgloadbmp(6,'1Fr.bmp')
                    cgdrawsprite(6,Data.position_reward_right,-Data.coins_offset_y)
                case 5
                    cgloadbmp(9,'5Fr.bmp')
                    cgdrawsprite(9,Data.position_reward_right,0)
                case 6
                    cgloadbmp(9,'5Fr.bmp')
                    cgdrawsprite(9,Data.position_reward_right,Data.coins_offset_y)
                    cgloadbmp(6,'1Fr.bmp')
                    cgdrawsprite(6,Data.position_reward_right,-Data.coins_offset_y)
                case 7
                    cgloadbmp(9,'5Fr.bmp')
                    cgdrawsprite(9,Data.position_reward_right,Data.coins_offset_y)
                    cgloadbmp(8,'2Fr.bmp')
                    cgdrawsprite(8,Data.position_reward_right,-Data.coins_offset_y)
                case 10
                    cgloadbmp(13, '10Fr.bmp')
                    cgdrawsprite(13, 170, 0)
            end
            
            % draw option boxes (left&right)
            cgpenwid(1)
            cgpencol(1,1,1);          % sets drawing colour to white
            %left
            cgdraw(Data.box_center_left-Data.box_size/2,Data.box_size/2,Data.box_center_left-Data.box_size/2,-Data.box_size/2)
            cgdraw(Data.box_center_left-Data.box_size/2,-Data.box_size/2, Data.box_center_left+Data.box_size/2, -Data.box_size/2)
            cgdraw(Data.box_center_left+Data.box_size/2, -Data.box_size/2, Data.box_center_left+Data.box_size/2, Data.box_size/2)
            cgdraw(Data.box_center_left+Data.box_size/2, Data.box_size/2, Data.box_center_left-Data.box_size/2,Data.box_size/2)
            %right
            cgdraw(Data.box_center_right-Data.box_size/2,Data.box_size/2,Data.box_center_right-Data.box_size/2,-Data.box_size/2)
            cgdraw(Data.box_center_right-Data.box_size/2,-Data.box_size/2, Data.box_center_right+Data.box_size/2, -Data.box_size/2)
            cgdraw(Data.box_center_right+Data.box_size/2, -Data.box_size/2, Data.box_center_right+Data.box_size/2, Data.box_size/2)
            cgdraw(Data.box_center_right+Data.box_size/2, Data.box_size/2, Data.box_center_right-Data.box_size/2,Data.box_size/2)
            
            % draw arrows and question mark
            cgpenwid(3)
            cgpencol(1,1,1);          % sets drawing colour to gray
            cgdraw(-80,-300,-150,-300)  % left arrow
            cgdraw(-150,-300,-130,-280)
            cgdraw(-150,-300,-130,-320)
            cgdraw(80,-300,150,-300)  % right arrow
            cgdraw(150,-300,130,-280)
            cgdraw(150,-300,130,-320)
            
            cgsetsprite(0)
            cgflip(0,0,0)
            
            cgdrawsprite(5,0,0) % draw stimuli presentation screen at 0,0
            
            cgfont('Helvetica', 60) % question mark indicating choice situation
            cgtext('?',0,-300)
            
            cgflip(0,0,0)
            
            t_present = tic;       % start measuring rt
            
            clearkeys;  % clear are stored key presses till now
            readkeys;   % now read all key presses
            
            waitkeydown( inf, [97 98 52] ); % waituntil LEFT or RIGHT is pressed, indexing the choice
            
            Data.iterativeMore.RT(1,(3*i-3+j)) = toc(t_present);  % choice response time measure
            
            [key, ~] = lastkeydown; % last button press
            
            
            if key == 97                    % if LEFT is pressed
                Data.iterativeMore.choiceEffort(1,(3*i-3+j)) = 0;
                cgdrawsprite(5,0,0);
                
                % draw choice confirmation arrow & make choice box blue
                cgpenwid(10)
                cgpencol(1,1,1);          % sets drawing colour to white
                cgdraw(-80,-300,-150,-300)  % left arrow
                cgdraw(-150,-300,-130,-280)
                cgdraw(-150,-300,-130,-320)
                
                cgpenwid(4)
                cgpencol(0,0,1);          % sets drawing colour to blue
                %left
                cgdraw(Data.box_center_left-Data.box_size/2,Data.box_size/2,Data.box_center_left-Data.box_size/2,-Data.box_size/2)
                cgdraw(Data.box_center_left-Data.box_size/2,-Data.box_size/2, Data.box_center_left+Data.box_size/2, -Data.box_size/2)
                cgdraw(Data.box_center_left+Data.box_size/2, -Data.box_size/2, Data.box_center_left+Data.box_size/2, Data.box_size/2)
                cgdraw(Data.box_center_left+Data.box_size/2, Data.box_size/2, Data.box_center_left-Data.box_size/2,Data.box_size/2)
                
                cgflip(0,0,0)
                wait(Data.timing.choice_feedback) % choice confirmation duration
                
                cgpencol(1,1,1);          % sets drawing colour to white
                cgfont('Helvetica', 50);  % font type and font size
                cgtext('+', 0, 0)         % fixation cross x=0, y=0
                if reward_left > 1
                    cgfont('Helvetica', 30);  % font type and font size
                    cgtext('ACHTUNG GLEICH M�SSEN SIE DR�CKEN',0,70 )    % text at x=0, y=70
                end
                cgflip(0,0,0)             % flips stuff from the buffer onto the screen
                
                wait(Data.timing.fixation_afterchoice)
                
                clear g newton
                newton = zeros(1,100);
                g = zeros(1, 100);
                
                effort_time = tic;
                
             for k = 1:100
                    time1 = time;
                    fprintf(s,';f?');
                    out = fscanf(s);
                    y = str2num(strrep(out, flag, ''));
                    newton(k) = y;
                    y = ((y/subject_max)*190);
                    g(k)=y;
                    
                    % draw feedback bar
                    cgpenwid(6)
                    cgpencol(1,1,1)
                    cgdraw(-25,-100,-25,100)
                    cgdraw(-25,100, 25, 100);
                    cgdraw(-25,-100, 25, -100)
                    cgdraw(25,100, 25, -100)
                    cgpencol(1,0.25,0)
                    cgrect(0,-97.5+(y/2),45,y)
                    
                    % draw effort-level
                    cgpenwid(6)
                    cgpencol(0.25,0.5,1) % sets colour to light blue
                    cgdraw(-30, effort_bar_left, 30, effort_bar_left) % sets the bar to the according effort level of left choice
                    
                    % name effort level
                    cgfont('Helvetica', Data.size_effort)
                    cgtext(effort_left_string,-65, effort_bar_left);
                    
                    % draw feedback arc
                    cgpencol(0,1,0)
                    cgpenwid(10)
                    cgarc(0,230,75,75,0,0+((k)*3.6))
                    if reward_left > 1
                        cgpencol(1,1,1)
                        cgfont('Helvetica',30)
                        cgtext('DR�CKEN!',0,300)
                    end
                    cgflip(0,0,0)
                    waituntil(time1+Data.timing.effort)
                end
                
                tElapsed = toc(effort_time);
                Data.iterativeMore.effort_time(1,(3*i-3+j)) = tElapsed;      % saves elapsed time in this trial
                
                Data.iterativeMore.effort_newton((3*i-3+j), 1:100) = newton;               % writes newton values of 100 loops to file
                Data.iterativeMore.effort_newton_mean(1,(3*i-3+j)) = mean(newton);
                
                
                % criterion if expended effort was sufficient to reach effort level
                % and according feedback
                
                if mean(Data.iterativeMore.effort_newton((3*i-3+j), 34:100)) >= Data.subject_max * ((effort_left)/100) * Data.forcemargin   % if the last 2/3 of the effort is >= than subj max
                    
                    Data.iterativeMore.success(1,(3*i-3+j)) = 1;     % writes 1 for success
                    
                    switch reward_left
                        case 1
                            cgpencol(0,1,0)
                            cgfont('Helvetica', Data.size_reward_feedback)
                            cgtext('Gewonnen!',0,160)
                            cgloadbmp(6,'1Fr.bmp')
                            cgdrawsprite(6,0,0)
                        case 1.05
                            cgpencol(0,1,0)
                            cgfont('Helvetica', Data.size_reward_feedback)
                            cgtext('Gewonnen!',0,160)
                            cgloadbmp(6,'1Fr.bmp')
                            cgdrawsprite(6,0,Data.coins_offset_y)
                            cgloadbmp(10,'5Rp.bmp')
                            cgdrawsprite(10,0,-Data.coins_offset_y)
                        case 1.1
                            cgpencol(0,1,0)
                            cgfont('Helvetica', Data.size_reward_feedback)
                            cgtext('Gewonnen!',0,160)
                            cgloadbmp(6,'1Fr.bmp')
                            cgdrawsprite(6,0,Data.coins_offset_y)
                            cgloadbmp(11,'10Rp.bmp')
                            cgdrawsprite(11,0,-Data.coins_offset_y)
                        case 1.2
                            cgpencol(0,1,0)
                            cgfont('Helvetica', Data.size_reward_feedback)
                            cgtext('Gewonnen!',0,160)
                            cgloadbmp(6,'1Fr.bmp')
                            cgdrawsprite(6,0,Data.coins_offset_y)
                            cgloadbmp(12,'20Rp.bmp')
                            cgdrawsprite(12,0,-Data.coins_offset_y)
                        case 1.5
                            cgpencol(0,1,0)
                            cgfont('Helvetica', Data.size_reward_feedback)
                            cgtext('Gewonnen!',0,160)
                            cgloadbmp(6,'1Fr.bmp')
                            cgdrawsprite(6,0,Data.coins_offset_y)
                            cgloadbmp(7,'50Rp.bmp')
                            cgdrawsprite(7,0,-Data.coins_offset_y)
                        case 2
                            cgpencol(0,1,0)
                            cgfont('Helvetica', Data.size_reward_feedback)
                            cgtext('Gewonnen!',0,160)
                            cgloadbmp(8,'2Fr.bmp')
                            cgdrawsprite(8,0,0)
                        case 2.5
                            cgpencol(0,1,0)
                            cgfont('Helvetica', Data.size_reward_feedback)
                            cgtext('Gewonnen!',0,160)
                            cgloadbmp(8,'2Fr.bmp')
                            cgdrawsprite(8,0,Data.coins_offset_y)
                            cgloadbmp(7,'50Rp.bmp')
                            cgdrawsprite(7,0,-Data.coins_offset_y)
                        case 3
                            cgpencol(0,1,0)
                            cgfont('Helvetica', Data.size_reward_feedback)
                            cgtext('Gewonnen!',0,160)
                            cgloadbmp(8,'2Fr.bmp')
                            cgdrawsprite(8,0,Data.coins_offset_y)
                            cgloadbmp(6,'1Fr.bmp')
                            cgdrawsprite(6,0,-Data.coins_offset_y)
                        case 5
                            cgpencol(0,1,0)
                            cgfont('Helvetica', Data.size_reward_feedback)
                            cgtext('Gewonnen!',0,160)
                            cgloadbmp(9,'5Fr.bmp')
                            cgdrawsprite(9,0,0)
                        case 6
                            cgpencol(0,1,0)
                            cgfont('Helvetica', Data.size_reward_feedback)
                            cgtext('Gewonnen!',0,160)
                            cgloadbmp(9,'5Fr.bmp')
                            cgdrawsprite(9,0,Data.coins_offset_y)
                            cgloadbmp(6,'1Fr.bmp')
                            cgdrawsprite(6,0,-Data.coins_offset_y)
                        case 7
                            cgpencol(0,1,0)
                            cgfont('Helvetica', Data.size_reward_feedback)
                            cgtext('Gewonnen!',0,160)
                            cgloadbmp(9,'5Fr.bmp')
                            cgdrawsprite(9,0,Data.coins_offset_y)
                            cgloadbmp(8,'2Fr.bmp')
                            cgdrawsprite(8,0,-Data.coins_offset_y)
                        case 10
                            cgpencol(0,1,0)
                            cgfont('Helvetica', Data.size_reward_feedback)
                            cgtext('Gewonnen!',0,160)
                            cgloadbmp(13, '10Fr.bmp')
                            cgdrawsprite(13,0, -Data.coins_offset_y)
                    end
                    
                    cgflip(0,0,0)
                    wait(Data.timing.feedback)
                    
                else
                    
                    Data.iterativeMore.success(1,(3*i-3+j)) = 0;     % writes 0 for failed
                    
                    cgpencol(1,1,1)
                    cgfont('Helvetica', Data.text_size)
                    cgtext('Leider nicht geschafft... Das n�chste mal st�rker dr�cken...',0,80)
                    cgloadbmp(6,'1Fr.bmp')
                    cgdrawsprite(6,0,0)
                    
                    cgflip(0,0,0);
                    wait(Data.timing.feedback)
                end
            end
            
            %%%%%
            if key == 98                    % if RIGHT is pressed
                Data.iterativeMore.choiceEffort(1,(3*i-3+j)) = 1;
                
                cgdrawsprite(5,0,0);
                
                % draw choice confirmation arrow & make choice box blue
                cgpenwid(10)
                cgpencol(1,1,1);          % sets drawing colour to white
                cgdraw(80,-300,150,-300)  % right arrow
                cgdraw(150,-300,130,-280)
                cgdraw(150,-300,130,-320)
                
                cgpenwid(4)
                cgpencol(0,0,1);          % sets drawing colour to blue
                %right
                cgdraw(Data.box_center_right-Data.box_size/2,Data.box_size/2,Data.box_center_right-Data.box_size/2,-Data.box_size/2)
                cgdraw(Data.box_center_right-Data.box_size/2,-Data.box_size/2, Data.box_center_right+Data.box_size/2, -Data.box_size/2)
                cgdraw(Data.box_center_right+Data.box_size/2, -Data.box_size/2, Data.box_center_right+Data.box_size/2, Data.box_size/2)
                cgdraw(Data.box_center_right+Data.box_size/2, Data.box_size/2, Data.box_center_right-Data.box_size/2,Data.box_size/2)
                
                cgflip(0,0,0)
                wait(Data.timing.choice_feedback) % choice confirmation duration
                
                cgpencol(1,1,1);          % sets drawing colour to white
                cgfont('Helvetica', 50);  % font type and font size
                cgtext('+', 0, 0)         % fixation cross x=0, y=0
                if reward_right > 1
                    cgfont('Helvetica', 30);  % font type and font size
                    cgtext('ACHTUNG GLEICH M�SSEN SIE DR�CKEN',0,70 )    % text at x=0, y=70
                end
                cgflip(0,0,0)             % flips stuff from the buffer onto the screen
                
                wait(Data.timing.fixation_afterchoice)
                
                clear g newton
                newton = zeros(1,100);
                g = zeros(1, 100);
                
                effort_time = tic;
                
             for k = 1:100
                    time1 = time;
                    fprintf(s,';f?');
                    out = fscanf(s);
                    y = str2num(strrep(out, flag, ''));
                    newton(k) = y;
                    y = ((y/subject_max)*190);
                    g(k)=y;
                    
                    % draw feedback bar
                    cgpenwid(6)
                    cgpencol(1,1,1)
                    cgdraw(-25,-100,-25,100)
                    cgdraw(-25,100, 25, 100);
                    cgdraw(-25,-100, 25, -100)
                    cgdraw(25,100, 25, -100)
                    cgpencol(1,0.25,0)
                    cgrect(0,-97.5+(y/2),45,y)
                    
                    % draw effort-level
                    cgpenwid(6)
                    cgpencol(0.25,0.5,1) % sets colour to light blue
                    cgdraw(-30, effort_bar_right, 30, effort_bar_right) % sets the bar to the according effort level of left choice
                    
                    % name effort level
                    cgfont('Helvetica', Data.size_effort)
                    cgtext(effort_right_string,-65, effort_bar_right);
                    
                    % draw feedback arc
                    cgpencol(0,1,0)
                    cgpenwid(10)
                    cgarc(0,230,75,75,0,0+((k)*3.6))
                    if reward_right > 1
                        cgpencol(1,1,1)
                        cgfont('Helvetica',30)
                        cgtext('DR�CKEN!',0,300)
                    end
                    
                    cgflip(0,0,0)
                    waituntil(time1+Data.timing.effort)
                end
                
                tElapsed = toc(effort_time);
                Data.iterativeMore.effort_time(1,(3*i-3+j)) = tElapsed;      % saves elapsed time in this trial
                
                Data.iterativeMore.effort_newton((3*i-3+j), 1:100) = newton;               % writes newton values of 100 loops to file
                Data.iterativeMore.effort_newton_mean(1,(3*i-3+j)) = mean(newton);
                
                % criterion if expended effort was sufficient to reach effort level
                % and according feedback
                
                if mean(Data.iterativeMore.effort_newton((3*i-3+j), 34:100)) >= Data.subject_max * ((effort_right)/100) * Data.forcemargin    % if the last 2/3 of the effort is >= than subj max
                    
                    Data.iterativeMore.sucess(1,(3*i-3+j)) = 1;     % writes 1 for success
                    
                    switch reward_right
                        case 1
                            cgpencol(0,1,0)
                            cgfont('Helvetica', Data.size_reward_feedback)
                            cgtext('Gewonnen!',0,160)
                            cgloadbmp(6,'1Fr.bmp')
                            cgdrawsprite(6,0,0)
                        case 1.05
                            cgpencol(0,1,0)
                            cgfont('Helvetica', Data.size_reward_feedback)
                            cgtext('Gewonnen!',0,160)
                            cgloadbmp(6,'1Fr.bmp')
                            cgdrawsprite(6,0,Data.coins_offset_y)
                            cgloadbmp(10,'5Rp.bmp')
                            cgdrawsprite(10,0,-Data.coins_offset_y)
                        case 1.1
                            cgpencol(0,1,0)
                            cgfont('Helvetica', Data.size_reward_feedback)
                            cgtext('Gewonnen!',0,160)
                            cgloadbmp(6,'1Fr.bmp')
                            cgdrawsprite(6,0,Data.coins_offset_y)
                            cgloadbmp(11,'10Rp.bmp')
                            cgdrawsprite(11,0,-Data.coins_offset_y)
                        case 1.2
                            cgpencol(0,1,0)
                            cgfont('Helvetica', Data.size_reward_feedback)
                            cgtext('Gewonnen!',0,160)
                            cgloadbmp(6,'1Fr.bmp')
                            cgdrawsprite(6,0,Data.coins_offset_y)
                            cgloadbmp(12,'20Rp.bmp')
                            cgdrawsprite(12,0,-Data.coins_offset_y)
                        case 1.5
                            cgpencol(0,1,0)
                            cgfont('Helvetica', Data.size_reward_feedback)
                            cgtext('Gewonnen!',0,160)
                            cgloadbmp(6,'1Fr.bmp')
                            cgdrawsprite(6,0,Data.coins_offset_y)
                            cgloadbmp(7,'50Rp.bmp')
                            cgdrawsprite(7,0,-Data.coins_offset_y)
                        case 2
                            cgpencol(0,1,0)
                            cgfont('Helvetica', Data.size_reward_feedback)
                            cgtext('Gewonnen!',0,160)
                            cgloadbmp(8,'2Fr.bmp')
                            cgdrawsprite(8,0,0)
                        case 2.5
                            cgpencol(0,1,0)
                            cgfont('Helvetica', Data.size_reward_feedback)
                            cgtext('Gewonnen!',0,160)
                            cgloadbmp(8,'2Fr.bmp')
                            cgdrawsprite(8,0,Data.coins_offset_y)
                            cgloadbmp(7,'50Rp.bmp')
                            cgdrawsprite(7,0,-Data.coins_offset_y)
                        case 3
                            cgpencol(0,1,0)
                            cgfont('Helvetica', Data.size_reward_feedback)
                            cgtext('Gewonnen!',0,160)
                            cgloadbmp(8,'2Fr.bmp')
                            cgdrawsprite(8,0,Data.coins_offset_y)
                            cgloadbmp(6,'1Fr.bmp')
                            cgdrawsprite(6,0,-Data.coins_offset_y)
                        case 5
                            cgpencol(0,1,0)
                            cgfont('Helvetica', Data.size_reward_feedback)
                            cgtext('Gewonnen!',0,160)
                            cgloadbmp(9,'5Fr.bmp')
                            cgdrawsprite(9,0,0)
                        case 6
                            cgpencol(0,1,0)
                            cgfont('Helvetica', Data.size_reward_feedback)
                            cgtext('Gewonnen!',0,160)
                            cgloadbmp(9,'5Fr.bmp')
                            cgdrawsprite(9,0,Data.coins_offset_y)
                            cgloadbmp(6,'1Fr.bmp')
                            cgdrawsprite(6,0,-Data.coins_offset_y)
                        case 7
                            cgpencol(0,1,0)
                            cgfont('Helvetica', Data.size_reward_feedback)
                            cgtext('Gewonnen!',0,160)
                            cgloadbmp(9,'5Fr.bmp')
                            cgdrawsprite(9,0,Data.coins_offset_y)
                            cgloadbmp(8,'2Fr.bmp')
                            cgdrawsprite(8,0,-Data.coins_offset_y)
                        case 10
                            cgpencol(0,1,0)
                            cgfont('Helvetica', Data.size_reward_feedback)
                            cgtext('Gewonnen!',0,160)
                            cgloadbmp(13, '10Fr.bmp')
                            cgdrawsprite(13,0, -Data.coins_offset_y)
                    end
                    
                    cgflip(0,0,0)
                    wait(Data.timing.feedback)
                    
                else
                    
                    Data.iterativeMore.sucess(1,(3*i-3+j)) = 0;     % writes 0 for no success
                    
                    cgpencol(1,1,1)
                    cgfont('Helvetica', Data.text_size)
                    cgtext('Leider nicht geschafft... Das n�chste mal st�rker dr�cken...',0,80)
                    cgloadbmp(6,'1Fr.bmp')
                    cgdrawsprite(6,0,0)
                    
                    cgflip(0,0,0);
                    wait(Data.timing.feedback)
                    
                end
            end
        end
    end
end

    %% CLOSE HANDGRIP PORT
    fclose(instrfind);
    
    
