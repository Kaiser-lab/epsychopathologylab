function [Data] = VAS_Effort(Data)

% VAS MIN MAX VALUES = -300 to 300

%% VARIABLES

Data.VAS_Effort = NaN(2,4);
Effort_levels = [40 60 80 100];
randomisation = randperm(4);

%% INTRO SCREEN

clearkeys;

cgpencol(0,0,0);    % set screen to black background
cgrect;

cgpencol(1,1,1);    % RGB colour setting for FONT (white)
cgfont('Helvetica',25);
cgtext('************************',0,60);
cgtext('V A S  E F F O R T',0,0);
cgtext('************************',0,-60);

% cgpencol(1,1,1);  % sets color to dark grey
% cgfont('Helvetica',23);
% cgtext('Dr�cken Sie die <Leertaste> um fortzufahren.',0,-280);
cgflip(0,0,0);  % flips offscreen buffer and clears to black

readkeys;
waitkeydown(inf, 71) % wait until Leertaste
clearkeys;


%% VAS FOR 4 EFFORT LEVELS

for i= 1:4
    
    switch i
        case 1
            random = randomisation(1);
            effort = Effort_levels(random);
        case 2
            random = randomisation(2);
            effort = Effort_levels(random);
        case 3
            random = randomisation(3);
            effort = Effort_levels(random);
        case 4
            random = randomisation(4);
            effort = Effort_levels(random);
    end
    
    Data.VAS_Effort(1,:) = randomisation;
    effort_bar = -100 + (effort/10)* 20;
    effort_string = strcat(num2str(effort),'%');
    Data.size_effort = 30;
    
    randNum = randperm(600);
    position_mouse = randNum(1) - 300;
    cgmouse(position_mouse,-250)
       
    bp=0;
    while ~bp
        [x,y,bs,bp]=cgmouse;
        
        % box
        cgpenwid(6)
        cgpencol(1,1,1);          % sets drawing colour to white
        cgdraw(0 - 25,-100, 0 - 25,100)
        cgdraw(0 - 25, 100, 0 + 25, 100)
        cgdraw(0 + 25, 100, 0 + 25, -100)
        cgdraw(0 + 25, -100, 0 - 25,-100)
        
        % effort_level rect
        cgpencol(1,0.25,0) % orange
        cgrect(0, (-100+(0.5*effort*200/100)), 45, effort*200/100)
        
        % effort-level marker
        cgpenwid(6)
        cgpencol(0.25,0.5,1) % sets colour to light blue
        cgdraw(-30, effort_bar, 30, effort_bar) % sets the bar to the according effort level of left choice
        
        % name effort level
        cgfont('Helvetica', Data.size_effort)
        cgtext(effort_string, 0-65, effort_bar);
        
        % name VAS ends
        cgpencol(1,1,1)
        cgfont('Helvetica', 25)
        cgtext('"sehr, sehr anstrengend"', 450,-250)
        
        cgtext('"�berhaupt nicht anstrengend"',-450,-250)
        
        % Frage
        cgtext('Wie empfanden Sie die untenstehende Kraft-Bedingung?', 0 , 250)
        
        cgpenwid(4)
        cgpencol(1,1,1)
        cgdraw(-300,-250,300,-250)
        
        cgdraw(-300,-240,-300,-260)
        cgdraw(300,-240,300,-260)
        
        cgdraw(240,-245,240,-255)
        cgdraw(180,-245,180,-255)
        cgdraw(120,-245,120,-255)
        cgdraw(60,-245,60,-255)
        cgdraw(0,-245,0,-255)
        cgdraw(-240,-245,-240,-255)
        cgdraw(-180,-245,-180,-255)
        cgdraw(-120,-245,-120,-255)
        cgdraw(-60,-245,-60,-255)
        
        if x > 300
            x=300;
        end
        
        if x < -300
            x=-300;
        end
        
        if x <= 300 & x >= -300 
            cgpencol(0,1,0)
            cgpenwid(6)
            cgdraw(x,-240,x,-260)
        end
        
        cgflip(0,0,0)
        
    end
    Data.VAS_Effort(2,i) = x;
end

cgflip(0,0,0)
end
