function [Data] = practice_choice_trials(Data)
%% BINARY CHOICE TRIALS - EFFORT DISCOUNTING
% presentation of all the possible choice pairs -> effort period ca. 5s ->
% feedback with according reward

%% LOAD SUBJECTS MAX

subject_max = Data.subject_max;


%% INTRO CHOICE TRIALS

clearkeys;

cgpencol(0,0,0);    % set screen to white background
cgrect;

cgpencol(1,1,1);    % RGB colour setting for FONT (0,0,0 represents black)
cgfont('Helvetica',25);
cgtext('*********************************',0,60);
cgtext('� B U N G S D U R C H G � N G E',0,0);
cgtext('*********************************',0,-60);

% cgpencol(1,1,1);  % sets color to dark grey
% cgfont('Helvetica',23);
% cgtext('Dr�cken Sie die <Leertaste> um fortzufahren.',0,-280);
cgflip(0,0,0);

readkeys;
waitkeydown(inf, 71) % wait until Leertaste
clearkeys;


%% READ HAND DYNANOMETER

s = serial('COM3');
s.BaudRate = 38400;
s.Terminator = 'CR';
flag = '!;f ';
fopen(s);


%% CHOICE TRIALS

random_practice = randperm(80); 

for i = random_practice(1:Data.practice_trials)
    
    which_row = i;               % load randomisation order
    
    effort_left = Data.effort_left(which_row);
    reward_left = Data.reward_left(which_row);
    reward_left_string = num2str(reward_left);
    effort_right = Data.effort_right(which_row);
    reward_right = Data.reward_right(which_row);
    reward_right_string = num2str(reward_right);
    
    effort_bar_left = -100 + (effort_left/10)* 20;
    effort_bar_right = -100 + (effort_right/10)* 20;
    
    effort_left_string = strcat(num2str(effort_left),'%');  % creates a string e.g. '15%'
    effort_right_string = strcat(num2str(effort_right),'%');
    
    % CHOICE SCREEN
    
    %make a sprite for the whole choice scree
    cgpencol(0,0,0);    % set screen to black background
    cgrect;
    cgfreesprite(5) % release prior trial from sprite number 5
    cgmakesprite(5,Data.resolution_width,Data.resolution_heigth)
    cgsetsprite(5)
    
    
    % left choice:
    % box
    cgpenwid(6)
    cgpencol(1,1,1);          % sets drawing colour to white
    cgdraw(Data.position_stimuli_left - 25,-100, Data.position_stimuli_left - 25,100)
    cgdraw(Data.position_stimuli_left - 25, 100, Data.position_stimuli_left + 25, 100)
    cgdraw(Data.position_stimuli_left + 25, 100, Data.position_stimuli_left + 25, -100)
    cgdraw(Data.position_stimuli_left + 25, -100, Data.position_stimuli_left - 25,-100)
    
    % effort_level rect
    cgpencol(1,0.25,0) % orange
    cgrect(Data.position_stimuli_left, (-100+(0.5*effort_left*200/100)), 45, effort_left*200/100)
    
    % effort-level marker
    cgpenwid(6)
    cgpencol(0.25,0.5,1) % sets colour to light blue
    cgdraw(Data.position_stimuli_left-30, effort_bar_left, Data.position_stimuli_left+30, effort_bar_left) % sets the bar to the according effort level of left choice
    
    % name effort level
    cgfont('Helvetica', Data.size_effort)
    cgtext(effort_left_string, Data.position_stimuli_left-65, effort_bar_left);
    
    % display reward (coins)
    switch reward_left
        case 1
            cgloadbmp(6,'1Fr.bmp')
            cgdrawsprite(6,Data.position_reward_left,0)
        case 1.5
            cgloadbmp(6,'1Fr.bmp')
            cgdrawsprite(6,Data.position_reward_left,Data.coins_offset_y)
            cgloadbmp(7,'50Rp.bmp')
            cgdrawsprite(7,Data.position_reward_left,-Data.coins_offset_y)
        case 2
            cgloadbmp(8,'2Fr.bmp')
            cgdrawsprite(8,Data.position_reward_left,0)
        case 2.5
            cgloadbmp(8,'2Fr.bmp')
            cgdrawsprite(8,Data.position_reward_left,Data.coins_offset_y)
            cgloadbmp(7,'50Rp.bmp')
            cgdrawsprite(7,Data.position_reward_left,-Data.coins_offset_y)
        case 3
            cgloadbmp(8,'2Fr.bmp')
            cgdrawsprite(8,Data.position_reward_left,Data.coins_offset_y)
            cgloadbmp(6,'1Fr.bmp')
            cgdrawsprite(6,Data.position_reward_left,-Data.coins_offset_y)
        case 5
            cgloadbmp(9,'5Fr.bmp')
            cgdrawsprite(9,Data.position_reward_left,0)
    end
    
    
    % right choice:
    % box
    cgpenwid(6)
    cgpencol(1,1,1);          % sets drawing colour to white
    cgdraw(Data.position_stimuli_right - 25,-100, Data.position_stimuli_right - 25,100)
    cgdraw(Data.position_stimuli_right - 25, 100, Data.position_stimuli_right + 25, 100)
    cgdraw(Data.position_stimuli_right + 25, 100, Data.position_stimuli_right + 25, -100)
    cgdraw(Data.position_stimuli_right + 25, -100, Data.position_stimuli_right - 25,-100)
    
    % effort_level rect
    cgpencol(1,0.25,0) %
    cgrect(Data.position_stimuli_right, (-100+(0.5*effort_right*200/100)), 45, effort_right*200/100)
    
    % effort-level marker
    cgpenwid(6)
    cgpencol(0.25,0.5,1) % sets colour to light blue
    cgdraw(Data.position_stimuli_right-30, effort_bar_right, Data.position_stimuli_right+30, effort_bar_right) % sets the bar to the according effort level of left choice
    
    % name effort level
    cgfont('Helvetica',Data.size_effort)
    cgtext(effort_right_string, Data.position_stimuli_right-65, effort_bar_right);
    
    % display reward level
    
    switch reward_right
        case 1
            cgloadbmp(6,'1Fr.bmp')
            cgdrawsprite(6,Data.position_reward_right,0)
        case 1.5
            cgloadbmp(6,'1Fr.bmp')
            cgdrawsprite(6,Data.position_reward_right,Data.coins_offset_y)
            cgloadbmp(7,'50Rp.bmp')
            cgdrawsprite(7,Data.position_reward_right,-Data.coins_offset_y)
        case 2
            cgloadbmp(8,'2Fr.bmp')
            cgdrawsprite(8,Data.position_reward_right,0)
        case 2.5
            cgloadbmp(8,'2Fr.bmp')
            cgdrawsprite(8,Data.position_reward_right,Data.coins_offset_y)
            cgloadbmp(7,'50Rp.bmp')
            cgdrawsprite(7,Data.position_reward_right,-Data.coins_offset_y)
        case 3
            cgloadbmp(8,'2Fr.bmp')
            cgdrawsprite(8,Data.position_reward_right,Data.coins_offset_y)
            cgloadbmp(6,'1Fr.bmp')
            cgdrawsprite(6,Data.position_reward_right,-Data.coins_offset_y)
        case 5
            cgloadbmp(9,'5Fr.bmp')
            cgdrawsprite(9,Data.position_reward_right,0)
    end
    
    % draw option boxes (left&right)
    cgpenwid(1)
    cgpencol(1,1,1);          % sets drawing colour to white
    %left
    cgdraw(Data.box_center_left-Data.box_size/2,Data.box_size/2,Data.box_center_left-Data.box_size/2,-Data.box_size/2)
    cgdraw(Data.box_center_left-Data.box_size/2,-Data.box_size/2, Data.box_center_left+Data.box_size/2, -Data.box_size/2)
    cgdraw(Data.box_center_left+Data.box_size/2, -Data.box_size/2, Data.box_center_left+Data.box_size/2, Data.box_size/2)
    cgdraw(Data.box_center_left+Data.box_size/2, Data.box_size/2, Data.box_center_left-Data.box_size/2,Data.box_size/2)
    %right
    cgdraw(Data.box_center_right-Data.box_size/2,Data.box_size/2,Data.box_center_right-Data.box_size/2,-Data.box_size/2)
    cgdraw(Data.box_center_right-Data.box_size/2,-Data.box_size/2, Data.box_center_right+Data.box_size/2, -Data.box_size/2)
    cgdraw(Data.box_center_right+Data.box_size/2, -Data.box_size/2, Data.box_center_right+Data.box_size/2, Data.box_size/2)
    cgdraw(Data.box_center_right+Data.box_size/2, Data.box_size/2, Data.box_center_right-Data.box_size/2,Data.box_size/2)
    
    % draw arrows and question mark
    cgpenwid(3)
    cgpencol(1,1,1);          % sets drawing colour to gray
    cgdraw(-80,-300,-150,-300)  % left arrow
    cgdraw(-150,-300,-130,-280)
    cgdraw(-150,-300,-130,-320)
    cgdraw(80,-300,150,-300)  % right arrow
    cgdraw(150,-300,130,-280)
    cgdraw(150,-300,130,-320)
    
    cgsetsprite(0)
    cgflip(0,0,0)
    
    cgdrawsprite(5,0,0) % draw stimuli presentation screen at 0,0
    
    cgfont('Helvetica', 60) % question mark indicating choice situation
    cgtext('?',0,-300)
    
    cgflip(0,0,0)
    
    t_present = tic;       % start measuring rt
    
    clearkeys;  % clear are stored key presses till now
    readkeys;   % now read all key presses
    
    waitkeydown( inf, [97 98 52] ); % waituntil LEFT or RIGHT is pressed, indexing the choice
    
    Data.exp_data(i, 9) = toc(t_present);  % choice response time measure
    
    [key, ~] = lastkeydown; % last button press
    
%     %%%%
%     if key == 52            % if esc is pressed (maybe deactivate when running experiments)
%         
%         break
%         
%     end
%     
    %%%%
    if key == 97                    % if LEFT is pressed
        
        cgdrawsprite(5,0,0);
        
        % draw choice confirmation arrow & make choice box blue
        cgpenwid(10)
        cgpencol(1,1,1);          % sets drawing colour to white
        cgdraw(-80,-300,-150,-300)  % left arrow
        cgdraw(-150,-300,-130,-280)
        cgdraw(-150,-300,-130,-320)
        
        cgpenwid(4)
        cgpencol(0,0,1);          % sets drawing colour to blue
        %left
        cgdraw(Data.box_center_left-Data.box_size/2,Data.box_size/2,Data.box_center_left-Data.box_size/2,-Data.box_size/2)
        cgdraw(Data.box_center_left-Data.box_size/2,-Data.box_size/2, Data.box_center_left+Data.box_size/2, -Data.box_size/2)
        cgdraw(Data.box_center_left+Data.box_size/2, -Data.box_size/2, Data.box_center_left+Data.box_size/2, Data.box_size/2)
        cgdraw(Data.box_center_left+Data.box_size/2, Data.box_size/2, Data.box_center_left-Data.box_size/2,Data.box_size/2)
        
        cgflip(0,0,0)
        wait(Data.timing.choice_feedback) % choice confirmation duration
            
        cgpencol(1,1,1);          % sets drawing colour to white
        cgfont('Helvetica', 50);  % font type and font size
        cgtext('+', 0, 0)         % fixation cross x=0, y=0
        if reward_left > 1
        cgfont('Helvetica', 30);  % font type and font size
        cgtext('ACHTUNG GLEICH M�SSEN SIE DR�CKEN',0,70 )    % text at x=0, y=70
        end
        cgflip(0,0,0)             % flips stuff from the buffer onto the screen
        
        wait(Data.timing.fixation_afterchoice)
        
        clear g newton
        newton = zeros(1,100);
        g = zeros(1, 100);
        
        
        
        for j = 1:100
            time1=time;
            fprintf(s,';f?');
            out = fscanf(s);
            y = str2num(strrep(out, flag, ''));
            newton(j) = y;
            y = ((y/subject_max)*190);
            g(j)=y;
            
            % draw feedback bar
            cgpenwid(6)
            cgpencol(1,1,1)
            cgdraw(-25,-100,-25,100)
            cgdraw(-25,100, 25, 100);
            cgdraw(-25,-100, 25, -100)
            cgdraw(25,100, 25, -100)
            cgpencol(1,0.25,0)
            cgrect(0,-97.5+(y/2),45,y)
            
            % draw effort-level
            cgpenwid(6)
            cgpencol(0.25,0.5,1) % sets colour to light blue
            cgdraw(-30, effort_bar_left, 30, effort_bar_left) % sets the bar to the according effort level of left choice
            
            % name effort level
            cgfont('Helvetica', Data.size_effort)
            cgtext(effort_left_string,-65, effort_bar_left);
            
            % draw feedback arc
            cgpencol(0,1,0)
            cgpenwid(10)
            cgarc(0,230,75,75,0,0+((j)*3.6))
            if reward_left > 1
            cgpencol(1,1,1)
            cgfont('Helvetica',30)
            cgtext('DR�CKEN!',0,300)
            end
            cgflip(0,0,0)
            waituntil(time1+Data.timing.effort)
        end
  
        
        effort_newton(i, :) = newton;     % writes newton values of 100 loops to file
        
        effort_newton_mean(i, 1) = mean(newton);                   % mean newton over the whole 100 loops
        
        
        % criterion if expended effort was sufficient to reach effort level
        % and according feedback
        
        if mean(effort_newton(i, 34:100)) >= Data.subject_max * ((effort_left)/100) * Data.forcemargin   % if the last 2/3 of the effort is >= than subj max
            
            
            switch reward_left
                case 1
                    cgpencol(0,1,0)
                    cgfont('Helvetica', Data.size_reward_feedback)
                    cgtext('Gewonnen!',0,160)
                    cgloadbmp(6,'1Fr.bmp')
                    cgdrawsprite(6,0,0)
                case 1.5
                    cgpencol(0,1,0)
                    cgfont('Helvetica', Data.size_reward_feedback)
                    cgtext('Gewonnen!',0,160)
                    cgloadbmp(6,'1Fr.bmp')
                    cgdrawsprite(6,0,Data.coins_offset_y)
                    cgloadbmp(7,'50Rp.bmp')
                    cgdrawsprite(7,0,-Data.coins_offset_y)
                case 2
                    cgpencol(0,1,0)
                    cgfont('Helvetica', Data.size_reward_feedback)
                    cgtext('Gewonnen!',0,160)
                    cgloadbmp(8,'2Fr.bmp')
                    cgdrawsprite(8,0,0)
                case 2.5
                    cgpencol(0,1,0)
                    cgfont('Helvetica', Data.size_reward_feedback)
                    cgtext('Gewonnen!',0,160)
                    cgloadbmp(8,'2Fr.bmp')
                    cgdrawsprite(8,0,Data.coins_offset_y)
                    cgloadbmp(7,'50Rp.bmp')
                    cgdrawsprite(7,0,-Data.coins_offset_y)
                case 3
                    cgpencol(0,1,0)
                    cgfont('Helvetica', Data.size_reward_feedback)
                    cgtext('Gewonnen!',0,160)
                    cgloadbmp(8,'2Fr.bmp')
                    cgdrawsprite(8,0,Data.coins_offset_y)
                    cgloadbmp(6,'1Fr.bmp')
                    cgdrawsprite(6,0,-Data.coins_offset_y)
                case 5
                    cgpencol(0,1,0)
                    cgfont('Helvetica', Data.size_reward_feedback)
                    cgtext('Gewonnen!',0,160)
                    cgloadbmp(9,'5Fr.bmp')
                    cgdrawsprite(9,0,0)
            end
            
            cgflip(0,0,0)
            wait(Data.timing.feedback)
            
        else
            
            
            cgpencol(1,1,1)
            cgfont('Helvetica', Data.text_size)
            cgtext('Leider nicht geschafft... Das n�chste mal st�rker dr�cken...',0,80)
            cgloadbmp(6,'1Fr.bmp')
            cgdrawsprite(6,0,0)
            
            cgflip(0,0,0);
            wait(Data.timing.feedback)
        end
    end
    
    %%%%%
    if key == 98                    % if RIGHT is pressed
      
        cgdrawsprite(5,0,0);
        
        % draw choice confirmation arrow & make choice box blue
        cgpenwid(10)
        cgpencol(1,1,1);          % sets drawing colour to white
        cgdraw(80,-300,150,-300)  % right arrow
        cgdraw(150,-300,130,-280)
        cgdraw(150,-300,130,-320)
        
        cgpenwid(4)
        cgpencol(0,0,1);          % sets drawing colour to blue
        %right
        cgdraw(Data.box_center_right-Data.box_size/2,Data.box_size/2,Data.box_center_right-Data.box_size/2,-Data.box_size/2)
        cgdraw(Data.box_center_right-Data.box_size/2,-Data.box_size/2, Data.box_center_right+Data.box_size/2, -Data.box_size/2)
        cgdraw(Data.box_center_right+Data.box_size/2, -Data.box_size/2, Data.box_center_right+Data.box_size/2, Data.box_size/2)
        cgdraw(Data.box_center_right+Data.box_size/2, Data.box_size/2, Data.box_center_right-Data.box_size/2,Data.box_size/2)
        
        cgflip(0,0,0)
        wait(Data.timing.choice_feedback) % choice confirmation duration
        
        cgpencol(1,1,1);          % sets drawing colour to white
        cgfont('Helvetica', 50);  % font type and font size
        cgtext('+', 0, 0)         % fixation cross x=0, y=0
        if reward_right > 1
            cgfont('Helvetica', 30);  % font type and font size
            cgtext('ACHTUNG GLEICH M�SSEN SIE DR�CKEN',0,70 )    % text at x=0, y=70
        end
        cgflip(0,0,0)             % flips stuff from the buffer onto the screen
        
        wait(Data.timing.fixation_afterchoice)
        
        clear g newton
        newton = zeros(1,100);
        g = zeros(1, 100);
                
        for j = 1:100
            
            time1 = time;
            fprintf(s,';f?');
            out = fscanf(s);
            y = str2num(strrep(out, flag, ''));
            newton(j) = y;
            y = ((y/subject_max)*190);
            g(j)=y;
            
            % draw feedback bar
            cgpenwid(6)
            cgpencol(1,1,1)
            cgdraw(-25,-100,-25,100)
            cgdraw(-25,100, 25, 100);
            cgdraw(-25,-100, 25, -100)
            cgdraw(25,100, 25, -100)
            cgpencol(1,0.25,0)
            cgrect(0,-97.5+(y/2),45,y)
            
            % draw effort-level
            cgpenwid(6)
            cgpencol(0.25,0.5,1) % sets colour to light blue
            cgdraw(-30, effort_bar_right, 30, effort_bar_right) % sets the bar to the according effort level of left choice
            
            % name effort level
            cgfont('Helvetica', Data.size_effort)
            cgtext(effort_right_string,-65, effort_bar_right);
            
            % draw feedback arc
            cgpencol(0,1,0)
            cgpenwid(10)
            cgarc(0,230,75,75,0,0+((j)*3.6))
            if reward_right > 1
            cgpencol(1,1,1)
            cgfont('Helvetica',30)
            cgtext('DR�CKEN!',0,300)
            end
            
            cgflip(0,0,0)
            waituntil(time1+Data.timing.effort)
        end
        

        effort_newton(i, :) = newton;     % writes newton values of 100 loops to file
        
        effort_newton_mean(i, 1) = mean(newton);                   % mean newton over the whole 100 loops
        
        % criterion if expended effort was sufficient to reach effort level
        % and according feedback
        
        if mean(effort_newton(i, 34:100)) >= Data.subject_max * ((effort_right)/100) * Data.forcemargin    % if the last 2/3 of the effort is >= than subj max
                        
            switch reward_right
                case 1
                    cgpencol(0,1,0)
                    cgfont('Helvetica', Data.size_reward_feedback)
                    cgtext('Gewonnen!',0,160)
                    cgloadbmp(6,'1Fr.bmp')
                    cgdrawsprite(6,0,0)
                case 1.5
                    cgpencol(0,1,0)
                    cgfont('Helvetica', Data.size_reward_feedback)
                    cgtext('Gewonnen!',0,160)
                    cgloadbmp(6,'1Fr.bmp')
                    cgdrawsprite(6,0,Data.coins_offset_y)
                    cgloadbmp(7,'50Rp.bmp')
                    cgdrawsprite(7,0,-Data.coins_offset_y)
                case 2
                    cgpencol(0,1,0)
                    cgfont('Helvetica', Data.size_reward_feedback)
                    cgtext('Gewonnen!',0,160)
                    cgloadbmp(8,'2Fr.bmp')
                    cgdrawsprite(8,0,0)
                case 2.5
                    cgpencol(0,1,0)
                    cgfont('Helvetica', Data.size_reward_feedback)
                    cgtext('Gewonnen!',0,160)
                    cgloadbmp(8,'2Fr.bmp')
                    cgdrawsprite(8,0,Data.coins_offset_y)
                    cgloadbmp(7,'50Rp.bmp')
                    cgdrawsprite(7,0,-Data.coins_offset_y)
                case 3
                    cgpencol(0,1,0)
                    cgfont('Helvetica', Data.size_reward_feedback)
                    cgtext('Gewonnen!',0,160)
                    cgloadbmp(8,'2Fr.bmp')
                    cgdrawsprite(8,0,Data.coins_offset_y)
                    cgloadbmp(6,'1Fr.bmp')
                    cgdrawsprite(6,0,-Data.coins_offset_y)
                case 5
                    cgpencol(0,1,0)
                    cgfont('Helvetica', Data.size_reward_feedback)
                    cgtext('Gewonnen!',0,160)
                    cgloadbmp(9,'5Fr.bmp')
                    cgdrawsprite(9,0,0)
            end
            
            cgflip(0,0,0)
            wait(Data.timing.feedback)
            
        else
                        
            cgpencol(1,1,1)
            cgfont('Helvetica', Data.text_size)
            cgtext('Leider nicht geschafft... Das n�chste mal st�rker dr�cken...',0,80)
            cgloadbmp(6,'1Fr.bmp')
            cgdrawsprite(6,0,0)
            
            cgflip(0,0,0);
            wait(Data.timing.feedback)
            
        end
    end
end


%% CLOSE HANDGRIP PORT

fclose(instrfind);


end

