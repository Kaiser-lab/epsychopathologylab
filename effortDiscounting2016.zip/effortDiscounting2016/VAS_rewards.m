function [Data] = VAS_rewards(Data)

% VAS MIN MAX VALUES = -300 to 300

%% VARIABLES

Data.VAS_rewards = NaN(8,3);
rewards = [0.05 0.10 0.20 0.50 1 2 5 10];

randomisation = randperm(8);
Data.VAS_rewards(:,1) = randomisation;


%% INTRO SCREEN

clearkeys;

cgpencol(0,0,0);    % set screen to black background
cgrect;

cgpencol(1,1,1);    % RGB colour setting for FONT (white)
cgfont('Helvetica',25);
cgtext('************************',0,60);
cgtext('V A S  REWARDS',0,0);
cgtext('************************',0,-60);

% cgpencol(1,1,1);  % sets color to dark grey
% cgfont('Helvetica',23);
% cgtext('Dr�cken Sie die <Leertaste> um fortzufahren.',0,-280);
cgflip(0,0,0);  % flips offscreen buffer and clears to black

readkeys;
waitkeydown(inf, 71) % wait until Leertaste
clearkeys;


%% VAS FOR 8 REWARDS (see above)

for i= 1:8
    
    row= randomisation(i);
    reward = rewards(row);
    Data.VAS_rewards(i,2) = reward;

    position_money = 0;
    
    randNum = randperm(600);
    position_mouse = randNum(1) - 300;
    cgmouse(position_mouse,-250)
    
    bp=0;
    while ~bp
        [x,y,bs,bp]=cgmouse;
        
        switch reward
            case 0.05
                cgloadbmp(6,'5Rp.bmp')
                cgdrawsprite(6,position_money,0)
            case 0.10
                cgloadbmp(7,'10Rp.bmp')
                cgdrawsprite(7,position_money,0)
            case 0.20
                cgloadbmp(8,'20Rp.bmp')
                cgdrawsprite(8,position_money,0)
            case 0.50
                cgloadbmp(9,'50Rp.bmp')
                cgdrawsprite(9,position_money,0)
            case 1
                cgloadbmp(10,'1Fr.bmp')
                cgdrawsprite(10,position_money,0)
            case 2
                cgloadbmp(11,'2Fr.bmp')
                cgdrawsprite(11,position_money,0)
            case 5
                cgloadbmp(12,'5Fr.bmp')
                cgdrawsprite(12,position_money,0)
            case 10
                cgloadbmp(13,'10Fr.bmp')
                cgdrawsprite(13,position_money,0)
        end
        
        % name VAS ends
        cgpencol(1,1,1)
        cgfont('Helvetica', 25)
        cgtext('"sehr fest"', 450,-250)
        
        cgtext('"�berhaupt nicht"',-450,-250)
        
        % Frage
        cgtext('Wie sehr w�rden Sie sich �ber diesen Geldbetrag freuen?', 0 , 250)
        
        cgpenwid(4)
        cgpencol(1,1,1)
        cgdraw(-300,-250,300,-250)
        
        cgdraw(-300,-240,-300,-260)
        cgdraw(300,-240,300,-260)
        
        cgdraw(240,-245,240,-255)
        cgdraw(180,-245,180,-255)
        cgdraw(120,-245,120,-255)
        cgdraw(60,-245,60,-255)
        cgdraw(0,-245,0,-255)
        cgdraw(-240,-245,-240,-255)
        cgdraw(-180,-245,-180,-255)
        cgdraw(-120,-245,-120,-255)
        cgdraw(-60,-245,-60,-255)
        
        if x > 300
            x=300;
        end
        
        if x < -300
            x=-300;
        end
        
        if x <= 300 & x >= -300 
            cgpencol(0,1,0)
            cgpenwid(6)
            cgdraw(x,-240,x,-260)
        end
        
        cgflip(0,0,0)
        
    end
    Data.VAS_rewards(i,3) = x;
end

cgflip(0,0,0)

end

