%% CALIBRATION
function [Data]= calibrate(Data)

%% INTRO CALIBRATION

clearkeys;

cgpencol(0,0,0);    % set screen to black background
cgrect;

cgpencol(1,1,1);    % RGB colour setting for FONT (white)
cgfont('Helvetica',25);
cgtext('*********************************',0,60);
cgtext('K A L I B R I E R U N G',0,0);
cgtext('*********************************',0,-60);

% cgpencol(1,1,1);  % sets color to dark grey
% cgfont('Helvetica',23);
% cgtext('Dr�cken Sie die <Leertaste> um fortzufahren.',0,-280);

cgflip(0,0,0);  % flips offscreen buffer and clears to black

readkeys;
waitkeydown(inf, 71) % wait until Leertaste
clearkeys;


%% READ HAND DYNANOMETER

s = serial('COM3');
s.BaudRate = 38400;
s.Terminator = 'CR';
flag = '!;f ';
fopen(s);

%% CALIBRATION

for calibration_iteration = 1:2         % 2 calibrationt trials
    
    if calibration_iteration ==2
        
        cgpencol(1,1,1);    % RGB colour setting for FONT (white)
        cgfont('Helvetica',25);
        cgtext('*********************************',0,60);
        cgtext('K A L I B R I E R U N G  2',0,0);
        cgtext('*********************************',0,-60);
        
%         cgpencol(1,1,1);  % sets color to dark grey
%         cgfont('Helvetica',23);
%         cgtext('Dr�cken Sie die <Leertaste> um fortzufahren.',0,-280);
        cgflip(0,0,0);  % flips offscreen buffer and clears to black
        
        readkeys;
        waitkeydown(inf, 71) % wait until Leertaste
        clearkeys;
    end
    
    cgpencol(1,1,1); cgfont('Helvetica', 50); cgtext('+',0,0);
    cgfont('Helvetica', 30); cgtext('Pause',0,70)
    cgflip(0,0,0);
    wait(4000)
    
    clear g newton
    newton = nan(1, 100);
    g = nan(1, 100);
    
    for i = 1:100
        time1=time;
        fprintf(s,';f?');   % ;f? = Kraftwert lesen
        out = fscanf(s);    % read input stream
        y = str2num(strrep(out, flag, ''));
        newton(i) = y;
        y = ((y/600)*190);
        g(i) = y;
        
        % draw feedback arc in the middle of the screen
        cgpencol(0,1,0)
        cgpenwid(10)
        cgarc(0,0,75,75,0,0+((i-100)*3.6))
        cgpencol(1,1,1)
        cgfont('Helvetica',30)
        cgtext('DR�CKEN!',0,100)
        
        cgflip(0,0,0)
        waituntil(time1+Data.timing.effort_calibration)
    end
    
    % log the calibration values
    Data.rawcalibration(calibration_iteration,:) = newton;
end


[maxVal1, position1] = max(Data.rawcalibration(1,:));
[maxVal2, position2] = max(Data.rawcalibration(2,:));

mean_maxforce(1) = mean(Data.rawcalibration(1,34:100));
mean_maxforce(2) = mean(Data.rawcalibration(2,34:100));

fatigue_index(1) = (((mean_maxforce(1) / maxVal1) -1) * 100) * -1;
fatigue_index(2) = (((mean_maxforce(2) / maxVal2) -1) * 100) * -1;

Data.mean_fatigue = mean(fatigue_index);

% set the subject max grip force
subject_max = mean(mean_maxforce);

% log the subject max
Data.subject_max = subject_max;


%% CLOSE HANDGRIP PORT

fclose(instrfind);


end

