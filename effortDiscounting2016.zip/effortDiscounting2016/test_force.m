function [Data]= test_force(Data)

%% LOAD SUBJECTS MAX

subject_max = Data.subject_max;


%% INTRO CHOICE TRIALS

clearkeys;

cgpencol(0,0,0);    % set screen to white background
cgrect;

cgpencol(1,1,1);    % RGB colour setting for FONT (0,0,0 represents black)
cgfont('Helvetica',25);
cgtext('*************************',0,60);
cgtext('T E S T   F O R C E ',0,0);
cgtext('*************************',0,-60);

% cgpencol(1,1,1);  % sets color to dark grey
% cgfont('Helvetica',23);
% cgtext('Dr�cken Sie die <Leertaste> um fortzufahren.',0,-280);
cgflip(0,0,0);

readkeys;
waitkeydown(inf, 71) % wait until Leertaste
clearkeys;


%% READ HAND DYNANOMETER

s = serial('COM3');
s.BaudRate = 38400;
s.Terminator = 'CR';
flag = '!;f ';
fopen(s);

%%

clear g newton
newton = zeros(1,100);
g = zeros(1, 100);

for j = 1:500
    fprintf(s,';f?');
    out = fscanf(s);
    y = str2num(strrep(out, flag, ''));
    newton(j) = y;
    y = ((y/subject_max)*190);
    g(j)=y;
    
    % draw feedback bar
    cgpenwid(6)
    cgpencol(1,1,1)
    cgdraw(-25,-100,-25,100)
    cgdraw(-25,100, 25, 100);
    cgdraw(-25,-100, 25, -100)
    cgdraw(25,100, 25, -100)
    cgpencol(1,0.25,0)
    cgrect(0,-97.5+(y/2),45,y)
    
    % draw effort-level
    cgpenwid(6)
    cgpencol(0.25,0.5,1) % sets colour to light blue
    cgdraw(-30, -100 + (40/10)* 20, 30, -100 + (40/10)* 20) % sets the bar to the according effort level of left choice
    cgdraw(-30, -100 + (60/10)* 20, 30, -100 + (60/10)* 20)
    cgdraw(-30, -100 + (80/10)* 20, 30,-100 + (80/10)* 20)
    cgdraw(-30, -100 + (100/10)* 20, 30, -100 + (100/10)* 20)
    
    % name effort level
    cgfont('Helvetica', Data.size_effort)
    cgtext('40%',-65, -100 + (40/10)* 20);
    cgtext('60%',-65, -100 + (60/10)* 20);
    cgtext('80%',-65, -100 + (80/10)* 20);
    cgtext('100%',-65, -100 + (100/10)* 20);
    
    cgflip(0,0,0)
    
end

%% CLOSE HANDGRIP PORT

fclose(instrfind);
end