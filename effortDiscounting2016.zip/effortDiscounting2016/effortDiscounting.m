%%% Effort Discounting - Inflammation study %%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%
%       effort-levels: 40%,60%,80%,100% of MVC 
%       default effort: 0%
%       reward-levels: 1.5 CHF, 2 CHF, 2.5 CHF, 3 CHF, 5 CHF      
%       4 trials per effort/reward pairing -> 80 total trials
%
%       Iterative Expansion to force preference revearsal:
%           Logistic function is fit to each effort level (ezfit). 
%           If no preference revearsal occurs for an effort level,
%           additional amounts of monetary rewards are presented for the
%           effort levels (either smaller: 1.20, 1.10, 1.05 CHf or higher: 6, 7, 10 CHF)
%
%       effort period: approx. 3.5 sec.
%       payout trials: 5
%       Average win if always effort = 2.8 CHF per pick (5 picks -> avg of 14 CHF)
%       
%   M. N. Hartmann-Riemer, PhD 
%   Psychiatric University Hospital Zurich, January 2016


%% PROMPT FOR SUBJECT INFO
subject_initials = input('subject initials:', 's');
subject_number = input('subject number (e.g. 003):');
subject_group = input('group (1:control, 2:SZ, 3:MDD):');

Data.subject.initials = subject_initials;   % subject info       
Data.subject.number = subject_number;
Data.subject.group = subject_group;


%% READ STIMULI PATH etc from textfile   
[Data.stimulus Data.effort_left Data.reward_left Data.effort_right Data.reward_right] = textread('input_text.txt','%n%n%n%n%n');

%% VARIABLES
Data.n_trials = length(Data.stimulus);
Data.practice_trials = 5;

Data.position_stimuli_left = -200;
Data.position_stimuli_right = 350;
Data.position_reward_left = -360;
Data.position_reward_right = 190;
Data.box_center_left = (Data.position_stimuli_left+Data.position_reward_left)/2;
Data.box_center_right = (Data.position_stimuli_right+Data.position_reward_right)/2;
Data.box_size = 400;
Data.coins_offset_y = 56;

Data.text_size = 30;

Data.size_reward = 50;
Data.size_reward_feedback = 40;
Data.size_CHF = 25;
Data.size_effort = 30;
Data.timing.stimulus = 2000;
Data.timing.choice_feedback = 1000;
Data.timing.fixation_afterchoice = 2000;
Data.timing.effort = 30;            % intrastimulus wait 30 ms -> 3.5 sec effort period   
Data.timing.effort_calibration = 30;
Data.timing.feedback = 3000;

Data.resolution_width = 1280;
Data.resolution_heigth = 1024;

Data.forcemargin = 0.95;    

%% RANDOMIZATION OF TRIALS     
    order = repmat((1:40)', 3, 1); % rep 1:4 from 1:40
    
    %rng('shuffle'); % Better than rand('seed',sum(100*clock)); (depricated)
    
    rand('seed',sum(100*clock));
    
    last_rand = randperm(Data.n_trials)';
    order = order(last_rand);
    
    shuffledCorrectly = false; % we assume it's not correct
    
    while ~shuffledCorrectly
        % check if okay
        for z=2:size(order, 1)
            % check if the last three numbers are the same, if so, lets shuffle
            % again
            if length(unique(order(z-1:z))) == 1
                last_rand = randperm(Data.n_trials);
                order = repmat((1:40)', 3, 1); % rep 1:4 from 1:40
                order = order(last_rand);
                disp('reshuffle');
                break; % we have to start over again
            end
            
            if z==size(order, 1)
                % if we made it so far, we're lucky and it worked so we end it
                shuffledCorrectly = true;
            end
        end
    end
    
    random_order = last_rand';
    Data.Random_Order = random_order;

%% CREATE DATA STRUCTURE FOR EXPERIMENT 
Data.exp_data = NaN(Data.n_trials,10);            % initialize data array
Data.exp_data_columns = {'stimulus','randomization','effort_left','reward_left','effort_right','reward_right','subject_choice_left', 'subject_choice_right', 'response_time', 'success'};  

Data.exp_data(:,1) = 1: Data.n_trials;
Data.exp_data(:,2) = Data.Random_Order;
Data.exp_data(:,3) = Data.effort_left(Data.Random_Order);   
Data.exp_data(:,4) = Data.reward_left(Data.Random_Order);
Data.exp_data(:,5) = Data.effort_right(Data.Random_Order);
Data.exp_data(:,6) = Data.reward_right(Data.Random_Order);

Data.subject = cell(2,4);

% Log the subject information in the cell array Data.subject
Data.subject(1,1)={'subject ID'};
Data.subject(1,2)={'Initials'};
Data.subject(1,3)={'start_exp'};
Data.subject(1,4)={'end_exp'};

Data.subject(2,1)= {subject_number};
Data.subject(2,2)= {subject_initials}  ;
Data.subject(2,3)={datestr(now, 'mmmm dd, yyyy HH:MM:SS.FFF AM')};  % log start time of experiment

%% INITIALIZE COGENT
%Configure Cogent: Involves several commands to configure required Cogent
%2000 features, e.g. config_display to configure display, config_sound to
%configure sound, config_keyboard, config_mouse etc.

SCREENMODE = 1;                 % 0 for small window, 1 for full screen, 2 for second screen if attached
SCREENRES = 5;                  % screen resolution (1=640x480, 2=800x600, 3=1024x768, 4=1152x864, 5=1280x1024, 6=1600x1200)

BLACK = [0 0 0];                % RGB/color parameters
WHITE = [1 1 1];

FONTNAME = 'Helvetica';             % font parameters
FONTSIZE_1 = 30;                % initial font size for displaying the instructions
NUMBER_OF_BUFFERS = 10;         % not really sure if I only need 10
config_keyboard();

%config_log();                   % command to write a log file

config_display(SCREENMODE, SCREENRES, BLACK, WHITE, FONTNAME, FONTSIZE_1, NUMBER_OF_BUFFERS);

%config_display( mode, resolution, background, foreground, fontname, fontsize, nbuffers, nbits, scale)

%% START COGENT AND OPEN CG SCREEN
start_cogent;

%% CALIBRATE HANDGRIP 1
% 2x for a 5s interval
Data = calibrate(Data);

%% TEST FORCE
Data = test_force(Data);

%% PRACTICE CHOICE TRIALS
Data = practice_choice_trials(Data);

%% CHOICE TRIALS
Data = choice_trials(Data);

%% ITERATIVE EXPANSION
iterativeExpansion;

%% LOTTERY
Data = lottery(Data);

%% CALIBRATE HANDGRIP 2
% 2x for a 3.5s interval
Data = calibrate2(Data);

%% VAS OF REWARD LEVELS
Data = VAS_rewards(Data);

%% VAS OF EFFORT LEVELS
Data = VAS_Effort(Data);

%% VAS OF CHOICES
Data = VAS_choices(Data);

%% SAVE SUBJECT FILE 
Data.subject(2,4)={datestr(now, 'mmmm dd, yyyy HH:MM:SS.FFF AM')};  % flog end time of experiment

file = strcat('data\',num2str(subject_number),subject_initials,'.mat');
save(file, 'Data')
%fileBackUp = strcat('Z:\Inflammation\Data_backup\effortDiscounting\',num2str(subject_number),subject_initials,'.mat');
%save(fileBackUp, 'Data')
clear all

%% STOP COGENT
stop_cogent;

