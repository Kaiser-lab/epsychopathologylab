
function [Data] = lottery(Data)
%
%
%% INTRO LOTTERY 1

clearkeys;

cgpencol(0,0,0);    % set screen to white background
cgrect;

cgpencol(1,1,1);    % RGB colour setting for FONT (0,0,0 represents black)
cgfont('Helvetica',Data.text_size);
cgtext('Geschafft!',0,40);
cgtext('Bitte rufen Sie den Versuchsleiter.',0,0);

% cgpencol(0.2,0.2,0.2);  % sets color to dark grey
% cgfont('Helvetica',23);
% cgtext('Dr�cken Sie die <Leertaste> um den Zufallsgenerator zu starten.',0,-280);

cgflip(0,0,0);

readkeys;
waitkeydown(inf, 71) % wait until Leertaste
clearkeys;


%% INTRO LOTTERY 2

clearkeys;

cgpencol(0,0,0);    % set screen to white background
cgrect;

cgpencol(1,1,1);    % RGB colour setting for FONT (0,0,0 represents black)
cgfont('Helvetica',Data.text_size);
% cgtext('xxx', 0, 80)
cgtext('Nun werden Ihre Gewinndurchg�nge ausgelost...',0,40);
cgtext('Es werden zuf�llig 5 Durchg�nge ausgew�hlt!',0,0);
% cgtext('xxx',0,-40);

cgpencol(1,1,1);  % sets color to dark grey
cgfont('Helvetica',23);
cgtext('Dr�cken Sie die <Leertaste> um den Zufallsgenerator zu starten.',0,-280);
cgflip(0,0,0);

readkeys;
waitkeydown(inf, 71) % wait until Leertaste
clearkeys;



%% Random order for lottery
rand('seed',sum(100*clock));    % seeds the random number generator with the clock time
random_order_lottery = randperm(Data.n_trials);    % randperm generates a random sequence of 1 to n non-repeating digits


%%
pick_numbers = random_order_lottery;


%%
for i = 1:5                             % pick 5 numbers
    
    pick_number = pick_numbers(i);
    
    pick_reward_left = Data.exp_data(pick_number,4);
    
    pick_reward_right = Data.exp_data(pick_number,6);
    
    
    %% if the decision in the random trial was left
    if Data.exp_data(pick_number,7) == 1
        
        if Data.exp_data(pick_number,10) == 1    % if it was succesful
            
            Data.lottery(1, i) = pick_reward_left;
            
            switch pick_reward_left
                case 1
                    cgloadbmp(6,'1Fr.bmp')
                    cgdrawsprite(6,0,0)
                case 1.5
                    cgloadbmp(6,'1Fr.bmp')
                    cgdrawsprite(6,0,Data.coins_offset_y)
                    cgloadbmp(7,'50Rp.bmp')
                    cgdrawsprite(7,0,-Data.coins_offset_y)
                case 2
                    cgloadbmp(8,'2Fr.bmp')
                    cgdrawsprite(8,0,0)
                case 2.5
                    cgloadbmp(8,'2Fr.bmp')
                    cgdrawsprite(8,0,Data.coins_offset_y)
                    cgloadbmp(7,'50Rp.bmp')
                    cgdrawsprite(7,0,-Data.coins_offset_y)
                case 3
                    cgloadbmp(8,'2Fr.bmp')
                    cgdrawsprite(8,0,Data.coins_offset_y)
                    cgloadbmp(6,'1Fr.bmp')
                    cgdrawsprite(6,0,-Data.coins_offset_y)
                case 5
                    cgloadbmp(9,'5Fr.bmp')
                    cgdrawsprite(9,0,0)
            end
            
            
            cgpencol(1,1,1);  % sets color to dark grey
            cgfont('Helvetica', Data.text_size);
            cgtext('Dr�cken Sie die <Leertaste> um den Zufallsgenerator zu starten.',0,-280);
            cgflip(0,0,0);
            
            readkeys;
            waitkeydown(inf, 71) % wait until Leertaste
            clearkeys;
            
            cgflip(0,0,0)
            
            wait(500)       % wait 500 ms until continuing the script
           
        else     % if it was not succesful
            
            cgloadbmp(6,'1Fr.bmp')
            cgdrawsprite(6,0,0)
            
            Data.lottery(1, i) = 1;

            cgpencol(1,1,1);  % sets color to dark white
            cgfont('Helvetica', Data.text_size);
            cgtext('Dr�cken Sie die <Leertaste> um den Zufallsgenerator zu starten.',0,-280);
            cgflip(0,0,0);
            
            readkeys;
            waitkeydown(inf, 71) % wait until Leertaste
            clearkeys;
            
            cgflip(0,0,0)
            wait(500);     % wait 500 ms until continuing the script
            
        end
        
        %% if the decision in the random trial was right
        
    else
        
        if Data.exp_data(pick_number,10) == 1    % if it was succesful
            
            Data.lottery(1, i) = pick_reward_right;
            
            switch pick_reward_right
                case 1
                    cgloadbmp(6,'1Fr.bmp')
                    cgdrawsprite(6,0,0)
                case 1.5
                    cgloadbmp(6,'1Fr.bmp')
                    cgdrawsprite(6,0,Data.coins_offset_y)
                    cgloadbmp(7,'50Rp.bmp')
                    cgdrawsprite(7,0,-Data.coins_offset_y)
                case 2
                    cgloadbmp(8,'2Fr.bmp')
                    cgdrawsprite(8,0,0)
                case 2.5
                    cgloadbmp(8,'2Fr.bmp')
                    cgdrawsprite(8,0,Data.coins_offset_y)
                    cgloadbmp(7,'50Rp.bmp')
                    cgdrawsprite(7,0,-Data.coins_offset_y)
                case 3
                    cgloadbmp(8,'2Fr.bmp')
                    cgdrawsprite(8,0,Data.coins_offset_y)
                    cgloadbmp(6,'1Fr.bmp')
                    cgdrawsprite(6,0,-Data.coins_offset_y)
                case 5
                    cgloadbmp(9,'5Fr.bmp')
                    cgdrawsprite(9,0,0)
            end
            
            cgpencol(1,1,1);  % sets color to dark grey
            cgfont('Helvetica', Data.text_size);
            cgtext('Dr�cken Sie die <Leertaste> um den Zufallsgenerator zu starten.',0,-280);
            cgflip(0,0,0)
            
            readkeys;
            waitkeydown(inf, 71) % wait until Leertaste
            clearkeys;
            cgflip(0,0,0)
            
            wait(500)       % wait 500 ms until continuing the script
           
        else     % if it was not succesful
            
            cgloadbmp(6,'1Fr.bmp')
            cgdrawsprite(6,0,0)
            
            Data.lottery(1, i) = 1;
 
            cgpencol(1,1,1);  % sets color to dark white
            cgfont('Helvetica', Data.text_size);
            cgtext('Dr�cken Sie die <Leertaste> um den Zufallsgenerator zu starten.',0,-280);
            cgflip(0,0,0);
            
            readkeys;
            waitkeydown(inf, 71) % wait until Leertaste
            clearkeys;    
            cgflip(0,0,0)
            
            wait(500);     % wait 500 ms until continuing the script
            
        end
    end
end


%% FEEBACK OF TOTAL WIN

lottery_total = sum(Data.lottery);
lottery_total_string = strcat(num2str(lottery_total),'  Franken');    % make a string total win & 'CHF'

clearkeys;

cgpencol(1,1,1);    % RGB colour setting for FONT (0,0,0 represents black)
cgfont('Helvetica',Data.text_size);
cgtext('Sie haben insgesamt folgenden Betrag gewonnen:',0,120);
cgfont('Helvetica',30)
cgtext(lottery_total_string,0,0)

cgfont('Helvetica',23);
cgtext('***** Vielen Dank f�r Ihre Teilnahme *****',0,-280);
cgflip(0,0,0);

readkeys;
waitkeydown(inf, 71) % wait until Leertaste
clearkeys;


end